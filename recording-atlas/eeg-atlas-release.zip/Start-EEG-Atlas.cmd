@echo off
chcp 65001 >nul
pushd "%~dp0"
".venv\Scripts\python.exe" -X utf8 "local_atlas.py"
if errorlevel 1 pause
popd

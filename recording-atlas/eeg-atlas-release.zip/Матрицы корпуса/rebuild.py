"""Run the recovered matrix builder and bibliography filter on the local corpus."""
import argparse
from collections import Counter
import csv
from datetime import datetime
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from corpus_review import corpus, saved_texts

SOURCE = HERE / "Исходный код"
PREFIX = "const WINDOW_MATRIX="


def counts(matrix):
    result = Counter()
    terms = matrix["terms"]
    levels = {tuple(pair) for pair in matrix["level_pairs"]}
    for item in matrix["articles"].values():
        for left,right in {(a,b) for a,b,_ in item["pairs"]}:
            a,b = terms[left],terms[right]
            if (b["level"],a["level"]) in levels:
                a,b = b,a
            result[a["level"],a["label"],b["level"],b["label"]] += 1
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--allow-partial", action="store_true")
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()
    registry = corpus()[1]
    local = saved_texts()
    jobs = [(aid, local.get(aid) or local.get(row.get("pmcid"))) for aid,row in registry.items()]
    missing = [aid for aid,path in jobs if path is None]
    if missing and not args.allow_partial:
        parser.error(f"Полных текстов нет для {len(missing)} статей. Дождитесь загрузки или укажите --allow-partial.")
    tasks = [(aid,path) for aid,path in jobs if path is not None]
    if args.limit:
        tasks = tasks[:args.limit]
    if not tasks:
        parser.error("Нет локальных текстов для расчёта.")
    output = HERE / ("Пересчёт " + datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
    builder = output / "matrices_newcorpus_2026-11-18"
    texts = builder / "report_matrices" / "texts"
    texts.mkdir(parents=True)
    for aid,path in tasks:
        text = path.read_text(encoding="utf-8-sig")
        text = re.sub(r"https?://\S+|www\.\S+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        (texts / (aid+".txt")).write_text(text,encoding="utf-8")
    with (builder / "frozen_input.csv").open("w",encoding="utf-8-sig",newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["article_id","year"])
        writer.writerows((aid,registry[aid]["year"]) for aid,_ in tasks)
    shutil.copy2(HERE / "dictionary_codebook11_v2.csv",builder)
    shutil.copy2(SOURCE / "build_matrix_window_data.py",builder)
    layers = output / "layers"
    layers.mkdir()
    shutil.copy2(SOURCE / "layer1_mechanical.py",layers)
    filter_text = (SOURCE / "drop_references_from_matrix.py").read_text(encoding="utf-8")
    filter_text,n = re.subn(r"(?m)^ROOT = .+$","ROOT = Path(__file__).resolve().parent",filter_text)
    assert n == 1
    filter_path = output / "drop_references_from_matrix.py"
    filter_path.write_text(filter_text,encoding="utf-8")
    subprocess.run([sys.executable,"-X","utf8",str(builder / "build_matrix_window_data.py"),
                    "--workers",str(args.workers)],cwd=output,check=True)
    subprocess.run([sys.executable,"-X","utf8",str(filter_path)],cwd=output,check=True)
    raw = (builder / "matrix-window-data_filtered.js").read_text(encoding="utf-8")
    matrix = json.loads(raw.removeprefix(PREFIX).strip().removesuffix(";"))
    baseline = json.loads((HERE / "matrix-window-data.json").read_text(encoding="utf-8"))
    observed, saved = counts(matrix), counts(baseline)
    with (output / "pairs.csv").open("w",encoding="utf-8-sig",newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["source_level","source_term","target_level","target_term","articles"])
        writer.writerows((*key,n) for key,n in sorted(observed.items()))
    with (output / "comparison.csv").open("w",encoding="utf-8-sig",newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["source_level","source_term","target_level","target_term","saved_articles","recounted_articles"])
        writer.writerows((*key,saved[key],observed[key]) for key in sorted(saved.keys() | observed.keys()))
    hashes_equal = sum(entry["sha256"]==baseline["articles"].get(aid,{}).get("sha256")
                       for aid,entry in matrix["articles"].items())
    summary = {"corpus_articles":len(registry),"processed":len(tasks),"missing":missing,
               "matching_text_hashes":hashes_equal,"nonzero_pairs":len(observed),
               "article_pair_occurrences":sum(observed.values())}
    (output / "summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"Матрицы: {len(tasks)} статей, {len(observed)} непустых ячеек. {output}",flush=True)


if __name__ == "__main__":
    main()

"""Read-only corpus queries exposed to a single Harness task."""
import argparse
from contextlib import closing
from functools import lru_cache
import json
from pathlib import Path
import re
import sqlite3

SEEDS = {
    "mains": ("power line", "line noise", "notch", "welch"),
    "channel": ("bad channel", "noisy channel", "flat channel", "interpolation"),
    "rest": ("resting state", "alpha power", "eyes closed", "eyes open", "welch"),
    "erp": ("event related potentials", "epoch", "baseline", "stimulus"),
    "ant": ("attention network test", "flanker", "event related potentials", "epoch"),
    "eye": ("ocular", "blink", "eog"), "heart": ("cardiac", "ecg"),
    "muscle": ("muscle artifact", "emg"), "motion": ("motion artifact", "accelerometer"),
}


def read_only(path):
    return sqlite3.connect(path.resolve().as_uri()+"?mode=ro", uri=True)


def terms(query):
    values = re.findall(r'[\w]+(?:[ -][\w]+){0,5}',query,flags=re.UNICODE)
    return [value[:100] for value in values[:16]]


def matching(db, query, limit=8, article_id=None):
    units = terms(query)
    if not units:
        return []
    # FTS operators come exclusively from this expression, not from caller input.
    expression = " OR ".join('"'+unit.replace("-", " ")+'"' for unit in units)
    extra, parameters = "", [expression]
    if article_id:
        extra = " AND id = ?"
        parameters.append(article_id)
    rows = db.execute(
        "SELECT id, text, coverage, rowid FROM passages WHERE passages MATCH ?"
        +extra+" ORDER BY bm25(passages), rowid LIMIT ?", (*parameters,min(200,limit*15))
    )
    result, seen = [], set()
    for aid,text,coverage,rowid in rows:
        if article_id is None and aid in seen:
            continue
        seen.add(aid)
        result.append({"id":aid,"section":rowid,"coverage":coverage,"text":text})
        if len(result)>=limit:
            break
    return result


def open_passage(db, aid, section):
    row=db.execute("SELECT id,text,coverage,rowid FROM passages WHERE id=? AND rowid=?",(aid,section)).fetchone()
    if not row:
        return None
    return dict(zip(("id","text","coverage","section"),row))


def main():
    parser=argparse.ArgumentParser()
    commands=parser.add_subparsers(dest="command",required=True)
    search=commands.add_parser("search")
    search.add_argument("query",help="Separate concepts with commas")
    search.add_argument("--id")
    opened=commands.add_parser("open")
    opened.add_argument("id")
    opened.add_argument("section",type=int)
    args=parser.parse_args()
    with closing(read_only(Path(__file__).with_name("corpus.sqlite"))) as db:
        result=matching(db,args.query,8,args.id) if args.command=="search" else open_passage(db,args.id,args.section)
    print(json.dumps(result,ensure_ascii=False))


if __name__=="__main__":
    main()

"""Extract readable UTF-8 text from downloaded, text-based PDF copies."""
import json
from pathlib import Path
import fitz

ROOT = Path(__file__).resolve().parents[1] / "literature_search_2026-11-16"
FULL = ROOT / "full_text_alternatives"
records = []
for pdf in sorted(FULL.glob("*.pdf")):
    target = pdf.with_suffix(".txt")
    try:
        doc = fitz.open(pdf)
        text = "\n\n".join(page.get_text("text") for page in doc)
        text = text.replace("\x00", "").strip()
        if len(text) > 100:
            target.write_text(text, encoding="utf-8")
            records.append({"pdf": pdf.name, "text": target.name, "pages": len(doc), "characters": len(text), "status": "extracted"})
        else:
            records.append({"pdf": pdf.name, "text": "", "pages": len(doc), "characters": len(text), "status": "image_only_or_no_text_layer"})
    except Exception as exc:
        records.append({"pdf": pdf.name, "text": "", "status": "extraction_error", "error": str(exc)})
    if len(records) % 100 == 0:
        (ROOT / "pdf_text_extraction.json").write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / "pdf_text_extraction.json").write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
from collections import Counter
print(json.dumps({"pdf_files": len(records), "outcomes": dict(Counter(x["status"] for x in records))}, ensure_ascii=False))

"""Download already-discovered OpenAlex open-access full-text locations."""
import json
import time
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from threading import Lock

import fetch_alternative_fulltext as fetcher

ROOT = fetcher.ROOT
STATUS_PATH = fetcher.STATUS_PATH
META_PATH = ROOT / "openalex_oa_locations.json"


def attempt(row, meta):
    for loc in meta.get("locations", []):
        result = fetcher.save_download(row["pmid"], loc)
        if result:
            return result
        time.sleep(0.3)
    return {
        "pmid": row["pmid"],
        "status": "oa_location_not_retrieved",
        "error": "OpenAlex lists OA location(s), but no full-text file passed validation",
        "openalex_id": meta.get("openalex_id", ""),
        "oa_locations": meta.get("locations", []),
    }


def main():
    rows = json.loads((ROOT / "bibliography.json").read_text(encoding="utf-8"))
    statuses = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
    by_pmid = {x["pmid"]: x for x in statuses["results"]}
    meta = json.loads(META_PATH.read_text(encoding="utf-8"))
    targets = [
        r for r in rows
        if r["pmid"] in meta
        and meta[r["pmid"]].get("locations")
        and by_pmid[r["pmid"]]["status"] not in ("downloaded_pmc_fulltext", "downloaded_openalex_oa_location")
        and r.get("pubmed_record_type") != "book_chapter_or_book_record"
    ]
    lock = Lock()
    done = 0
    new_count = 0

    def save_checkpoint():
        statuses["results"] = list(by_pmid.values())
        STATUS_PATH.write_text(json.dumps(statuses, ensure_ascii=False, indent=2), encoding="utf-8")

    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(attempt, row, meta[row["pmid"]]): row for row in targets}
        for future in as_completed(futures):
            result = future.result()
            pmid = result["pmid"]
            with lock:
                old = by_pmid[pmid]
                old.update(result)
                done += 1
                if result["status"] == "downloaded_openalex_oa_location":
                    new_count += 1
                if done % 25 == 0 or done == len(targets):
                    save_checkpoint()
                    print(f"Downloaded alternatives {done}/{len(targets)}; new files {new_count}", flush=True)

    statuses["results"] = list(by_pmid.values())
    from collections import Counter
    counts = Counter(x["status"] for x in statuses["results"])
    statuses["completed"] = len(statuses["results"])
    statuses["status_counts"] = dict(counts)
    statuses["alternative_download_completed_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    STATUS_PATH.write_text(json.dumps(statuses, ensure_ascii=False, indent=2), encoding="utf-8")
    for row in rows:
        row["full_text_status"] = by_pmid[row["pmid"]]["status"]
        row["full_text_path"] = by_pmid[row["pmid"]].get("path", "")
    (ROOT / "bibliography.json").write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
    with (ROOT / "bibliography.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"new_alternative_full_texts": new_count, "status_counts": dict(counts)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

"""Find and download legally open article copies using OpenAlex OA locations."""
from __future__ import annotations

import csv
import gzip
import hashlib
import html
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "literature_search_2026-11-16"
API_CACHE = ROOT / "openalex_oa_locations.json"
API_PROVENANCE = ROOT / "openalex_api_provenance.json"
STATUS_PATH = ROOT / "fulltext_download_status.json"
FULL = ROOT / "full_text_alternatives"
HEADERS = {"User-Agent": "EEGQualityLiteratureReview/1.0 (open-access copy retrieval)", "Accept-Encoding": "gzip"}
FIELDS = "id,doi,ids,open_access,best_oa_location,locations"


def get_json(url: str, tries: int = 6) -> tuple[bytes, dict]:
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=45) as response:
                raw = response.read()
            if raw[:2] == b"\x1f\x8b":
                raw = gzip.decompress(raw)
            return raw, json.loads(raw)
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504) and attempt + 1 < tries:
                time.sleep(min(60, 2**attempt * 2))
                continue
            raise
    raise RuntimeError("retry limit exceeded")


def clean_doi(value: str) -> str:
    value = (value or "").strip().lower()
    value = re.sub(r"^https?://(dx\.)?doi\.org/", "", value)
    return value


def batch_api(filter_value: str) -> tuple[list[dict], str]:
    url = "https://api.openalex.org/works?" + urllib.parse.urlencode(
        {"filter": filter_value, "per_page": 100, "select": FIELDS}
    )
    raw, obj = get_json(url)
    return obj.get("results", []), hashlib.sha256(raw).hexdigest()


def oa_locations(work: dict) -> list[dict]:
    candidates = []
    if work.get("best_oa_location"):
        candidates.append(work["best_oa_location"])
    candidates.extend(work.get("locations") or [])
    by_url = {}
    for loc in candidates:
        if not loc or not loc.get("is_oa"):
            continue
        pdf = loc.get("pdf_url")
        landing = loc.get("landing_page_url")
        for url, kind in ((pdf, "pdf"), (landing, "landing")):
            if not url or not url.startswith("http"):
                continue
            entry = {
                "url": url,
                "kind": kind,
                "source_name": (loc.get("source") or {}).get("display_name", ""),
                "source_type": (loc.get("source") or {}).get("type", ""),
                "license": loc.get("license"),
                "version": loc.get("version"),
                "is_oa": True,
            }
            by_url.setdefault(url, entry)
    result = list(by_url.values())
    result.sort(key=lambda x: (x["kind"] != "pdf", x["source_type"] != "repository"))
    return result


class TextExtractor(HTMLParser):
    BLOCKS = {"p", "div", "section", "article", "h1", "h2", "h3", "h4", "li", "tr"}
    DROP = {"script", "style", "noscript", "svg", "nav", "footer", "header", "aside"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.parts: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag in self.DROP:
            self.depth += 1
        elif not self.depth and tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self.DROP and self.depth:
            self.depth -= 1
        elif not self.depth and tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.depth:
            text = re.sub(r"\s+", " ", html.unescape(data)).strip()
            if text:
                self.parts.append(text)


def save_download(pmid: str, location: dict) -> dict | None:
    req = urllib.request.Request(location["url"], headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            content_type = (response.headers.get("Content-Type") or "").lower()
            final_url = response.geturl()
            raw = response.read(80 * 1024 * 1024 + 1)
        if len(raw) > 80 * 1024 * 1024:
            return None
        if raw[:2] == b"\x1f\x8b":
            raw = gzip.decompress(raw)
        stem = f"PMID{pmid}"
        suffix = ""
        plain = ""
        if raw.startswith(b"%PDF-"):
            suffix = ".pdf"
        elif b"<html" in raw[:2048].lower() or "text/html" in content_type:
            decoded = raw.decode("utf-8", errors="replace")
            parser = TextExtractor()
            parser.feed(decoded)
            plain = re.sub(r"\n{3,}", "\n\n", "\n".join(parser.parts)).strip()
            low = plain.lower()
            if len(plain) < 3000 or any(x in low[:2500] for x in ("captcha", "access denied", "sign in to access", "subscribe to access", "cloudflare")):
                return None
            # Keep the source HTML and an extracted UTF-8 reading copy.
            (FULL / f"{stem}.html").write_bytes(raw)
            (FULL / f"{stem}.txt").write_text(plain, encoding="utf-8")
            suffix = ".html"
        elif b"<" in raw[:256] and any(x in content_type for x in ("xml", "text/")):
            decoded = raw.decode("utf-8", errors="replace")
            if len(decoded) < 3000:
                return None
            (FULL / f"{stem}.xml").write_bytes(raw)
            parser = TextExtractor()
            parser.feed(decoded)
            plain = "\n".join(parser.parts).strip()
            if len(plain) > 500:
                (FULL / f"{stem}.txt").write_text(plain, encoding="utf-8")
            suffix = ".xml"
        else:
            return None
        path = FULL / f"{stem}{suffix}"
        if suffix == ".pdf":
            path.write_bytes(raw)
        return {
            "pmid": pmid,
            "status": "downloaded_openalex_oa_location",
            "path": str(path.relative_to(ROOT)),
            "text_path": str((FULL / f"{stem}.txt").relative_to(ROOT)) if (FULL / f"{stem}.txt").exists() else "",
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "download_url": final_url,
            "openalex_source": location.get("source_name", ""),
            "openalex_source_type": location.get("source_type", ""),
            "openalex_license": location.get("license"),
            "openalex_version": location.get("version"),
        }
    except Exception:
        return None


def main():
    FULL.mkdir(parents=True, exist_ok=True)
    rows = json.loads((ROOT / "bibliography.json").read_text(encoding="utf-8"))
    download_status = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
    status_by_pmid = {x["pmid"]: x for x in download_status["results"]}
    pending = [
        r for r in rows
        if r.get("full_text_status") != "downloaded_pmc_fulltext"
        and r.get("full_text_status") != "not_attempted_non_article_record"
    ]
    works_by_doi: dict[str, dict] = {}
    works_by_pmid: dict[str, dict] = {}
    hashes = []
    if API_CACHE.exists():
        cache = json.loads(API_CACHE.read_text(encoding="utf-8"))
        works_by_doi = {clean_doi(k): v for k, v in cache.get("works_by_doi", {}).items()}
        works_by_pmid = cache.get("works_by_pmid", {})
        hashes = cache.get("response_sha256", [])
    have_doi = set(works_by_doi)
    missing_doi = sorted({clean_doi(r.get("doi", "")) for r in pending} - {""} - have_doi)
    for start in range(0, len(missing_doi), 40):
        values = missing_doi[start:start + 40]
        result, digest = batch_api("doi:" + "|".join(values))
        hashes.append(digest)
        for work in result:
            works_by_doi[clean_doi(work.get("doi", ""))] = work
        API_CACHE.write_text(json.dumps({"works_by_doi": works_by_doi, "works_by_pmid": works_by_pmid, "response_sha256": hashes}, ensure_ascii=False), encoding="utf-8")
        print(f"OpenAlex DOI metadata {min(start + 40, len(missing_doi))}/{len(missing_doi)}", flush=True)
        time.sleep(0.35)
    no_doi = sorted({r["pmid"] for r in pending if not r.get("doi")} - set(works_by_pmid))
    for start in range(0, len(no_doi), 40):
        values = no_doi[start:start + 40]
        result, digest = batch_api("ids.pmid:" + "|".join(values))
        hashes.append(digest)
        for work in result:
            for pmid in (work.get("ids") or {}).get("pmid", "").split("|"):
                if pmid:
                    works_by_pmid[pmid] = work
        API_CACHE.write_text(json.dumps({"works_by_doi": works_by_doi, "works_by_pmid": works_by_pmid, "response_sha256": hashes}, ensure_ascii=False), encoding="utf-8")
        print(f"OpenAlex PMID metadata {min(start + 40, len(no_doi))}/{len(no_doi)}", flush=True)
        time.sleep(0.35)

    oa_by_pmid = {}
    for row in pending:
        work = works_by_doi.get(clean_doi(row.get("doi", ""))) or works_by_pmid.get(row["pmid"])
        locs = oa_locations(work) if work else []
        oa_by_pmid[row["pmid"]] = {"openalex_id": work.get("id") if work else "", "is_oa": bool((work or {}).get("open_access", {}).get("is_oa")), "oa_status": (work or {}).get("open_access", {}).get("oa_status"), "locations": locs}
    (ROOT / "openalex_oa_locations.json").write_text(json.dumps(oa_by_pmid, ensure_ascii=False, indent=2), encoding="utf-8")
    API_PROVENANCE.write_text(json.dumps({"api": "OpenAlex works API", "retrieved_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "response_sha256": hashes, "doi_queries": len(missing_doi), "pmid_queries": len(no_doi)}, ensure_ascii=False, indent=2), encoding="utf-8")

    downloaded = 0
    for idx, row in enumerate(pending, 1):
        current = status_by_pmid[row["pmid"]]
        meta = oa_by_pmid[row["pmid"]]
        if not meta["locations"]:
            current.update(status="no_openalex_oa_copy", error="No OA full-text location listed by OpenAlex", openalex_id=meta["openalex_id"])
        else:
            result = None
            for location in meta["locations"]:
                result = save_download(row["pmid"], location)
                if result:
                    current.update(result)
                    downloaded += 1
                    break
                time.sleep(0.7)
            if not result:
                current.update(status="oa_location_not_retrieved", error="OpenAlex lists OA location(s), but no full-text file passed validation", openalex_id=meta["openalex_id"], oa_locations=meta["locations"])
        if idx % 25 == 0 or idx == len(pending):
            download_status["results"] = list(status_by_pmid.values())
            STATUS_PATH.write_text(json.dumps(download_status, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"Alternative fulltext {idx}/{len(pending)}; new files {downloaded}", flush=True)
        time.sleep(0.5)

    download_status["results"] = list(status_by_pmid.values())
    counts = Counter(x["status"] for x in download_status["results"])
    download_status["completed"] = len(download_status["results"])
    download_status["status_counts"] = dict(counts)
    download_status["alternative_source_completed_at_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    STATUS_PATH.write_text(json.dumps(download_status, ensure_ascii=False, indent=2), encoding="utf-8")
    for row in rows:
        item = status_by_pmid[row["pmid"]]
        row["full_text_status"] = item["status"]
        row["full_text_path"] = item.get("path", "")
    (ROOT / "bibliography.json").write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
    with (ROOT / "bibliography.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"new_downloads": downloaded, "status_counts": dict(counts)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

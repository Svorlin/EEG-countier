"""Restore open full texts for the fixed article IDs in the EEG atlas."""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import re
import sys
from threading import Lock
from time import monotonic, sleep
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET

import fitz
import requests
from bs4 import BeautifulSoup

from fetch_alternative_fulltext import clean_doi, oa_locations
from fetch_openaire_open_texts import open_urls

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from corpus_review import corpus, saved_texts

DESTINATION = ROOT / "Корпус полные тексты"
EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
EUROPE_PMC = "https://www.ebi.ac.uk/europepmc/webservices/rest"
BIOC = "https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_json"
OPENAIRE = "https://api.openaire.eu/graph/v4/research-products"
OPENALEX = "https://api.openalex.org/works"
LOCK = Lock()
NEXT_REQUEST = {}
COOLDOWN = {}
USER_AGENT = "EEG-Atlas-corpus-restoration/1.0"


def get(url, params=None, *, tries=2, read_timeout=12):
    host = urlsplit(url).netloc
    interval = 0.42 if host.endswith("ncbi.nlm.nih.gov") else 0.45
    for attempt in range(tries):
        with LOCK:
            now = monotonic()
            if COOLDOWN.get(host,0) > now:
                return None
            start = max(now, NEXT_REQUEST.get(host, now))
            NEXT_REQUEST[host] = start + interval
        sleep(max(0, start - now))
        response = None
        try:
            response = requests.get(url, params=params, timeout=(6, read_timeout), stream=True,
                                    headers={"User-Agent": USER_AGENT})
            if response.ok:
                parts = bytearray()
                deadline = monotonic() + 30
                for chunk in response.iter_content(128 * 1024):
                    parts.extend(chunk)
                    if len(parts) > 45_000_000 or monotonic() > deadline:
                        return None
                return bytes(parts)
            if response.status_code not in {429, 500, 502, 503, 504}:
                return None
            retry = response.headers.get("Retry-After", "")
            if response.status_code == 429:
                with LOCK:
                    COOLDOWN[host] = monotonic() + (int(retry) if retry.isdigit() else 30)
                return None
        except requests.RequestException:
            pass
        finally:
            if response is not None:
                response.close()
        if attempt+1 < tries:
            sleep(1 + attempt * 2)
    return None


def xml_articles(raw):
    if raw:
        try:
            yield from ET.fromstring(raw).iter("article")
        except ET.ParseError:
            return


def xml_text(article):
    body = article.find("body")
    if body is None:
        return ""
    title = article.find("./front/article-meta/title-group/article-title")
    abstract = article.find("./front/article-meta/abstract")
    parts = [" ".join("".join(item.itertext()).split()) for item in (title, abstract) if item is not None]
    parts.extend(" ".join("".join(item.itertext()).split())
                 for item in body.iter() if item.tag in {"title", "p", "tr"})
    return "\n\n".join(part for part in parts if part)


def save(row, text, source):
    # The embedded text size is a conservative completeness check, especially for abstracts.
    if len(text) < max(900, min(int(row.get("chars") or 0) * 0.32, 12_000)):
        return None
    path = DESTINATION / (row["id"] + ".txt")
    temp = path.with_suffix(".tmp")
    temp.write_text(text.rstrip() + "\n", encoding="utf-8")
    temp.replace(path)
    return {"id": row["id"], "status": "restored", "source": source, "chars": len(text)}


def pmc_batch(rows):
    by_pmc = {row["pmcid"]: row for row in rows}
    raw = get(EUTILS, {"db": "pmc", "id": ",".join(pmc[3:] for pmc in by_pmc),
                       "retmode": "xml", "tool": "eeg_atlas"},tries=3,read_timeout=25)
    for article in xml_articles(raw):
        pmcid = article.findtext("./front/article-meta/article-id[@pub-id-type='pmcid']")
        row = by_pmc.get(pmcid)
        if row:
            result = save(row, xml_text(article), "PMC EFetch · " + pmcid)
            if result:
                yield result


def json_response(raw):
    try:
        return json.loads(raw) if raw else {}
    except (ValueError, UnicodeError):
        return {}


def oa_download(url, depth=0):
    parsed = urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname:
        return ""
    if parsed.hostname.endswith("ncbi.nlm.nih.gov"):
        return ""
    raw = get(url,tries=1)
    if not raw:
        return ""
    if raw.startswith(b"%PDF"):
        try:
            with fitz.open(stream=raw, filetype="pdf") as document:
                return "\n\n".join(page.get_text() for page in document)
        except (RuntimeError, ValueError):
            return ""
    for article in xml_articles(raw):
        text = xml_text(article)
        if text:
            return text
    soup = BeautifulSoup(raw, "html.parser")
    pdf = soup.find("meta", attrs={"name": "citation_pdf_url"})
    if pdf and not depth and pdf.get("content"):
        text = oa_download(pdf["content"], depth=1)
        if text:
            return text
    for node in soup.select("script, style, nav, aside, header, footer"):
        node.decompose()
    sections = soup.select("article [id*='sec'], article section, [itemprop='articleBody'], .article-body")
    if not sections:
        return ""
    return "\n\n".join(dict.fromkeys(
        node.get_text(" ", strip=True) for section in sections for node in section.select("p, h2, h3, tr")
    ))


def matches_title(text, title):
    words = set(re.findall(r"[a-z0-9]{4,}", title.casefold()))
    front = set(re.findall(r"[a-z0-9]{4,}", text[:6000].casefold()))
    return not words or len(words & front) / len(words) >= 0.65


def list_locations(batch):
    lookup = {clean_doi(row.get("doi")):row["id"] for row in batch if row.get("doi")}
    pmids = {row["pmid"]:row["id"] for row in batch if row.get("pmid")}
    locations = {row["id"]:[] for row in batch}
    if lookup:
        params = {"filter":"doi:"+"|".join(lookup), "per_page":100,
                  "select":"doi,locations,best_oa_location"}
        if key := os.environ.get("OPENALEX_API_KEY"):
            params["api_key"] = key
        for work in json_response(get(OPENALEX,params)).get("results") or []:
            if aid := lookup.get(clean_doi(work.get("doi"))):
                locations[aid].extend(oa_locations(work))
    for prefix,identifiers in (("ids.doi:",lookup),("ids.pmid:",{row["pmid"]:row["id"] for row in batch if not row.get("doi")})):
        if not identifiers:
            continue
        result = json_response(get(OPENAIRE,{"filter":prefix+"|".join(identifiers),
                                            "page_size":100,"select":"pids,instances,bestAccessRight,links"}))
        for work in result.get("results") or []:
            mapped = set()
            for pid in work.get("pids") or []:
                if pid.get("scheme") == "doi":
                    aid = lookup.get(clean_doi(pid.get("value")))
                elif pid.get("scheme") == "pmid":
                    aid = pmids.get(pid.get("value"))
                else:
                    continue
                if aid:
                    mapped.add(aid)
            for aid in mapped:
                locations[aid].extend(open_urls(work))
    return locations


def alternative(row,candidates):
    pmcid = row.get("pmcid")
    doi = clean_doi(row.get("doi"))
    tried = set()
    for location in candidates:
        url = location["url"]
        if url in tried:
            continue
        tried.add(url)
        text = oa_download(url)
        if matches_title(text, row["title"]):
            restored = save(row, text, url)
            if restored:
                return restored
    if pmcid:
        for article in xml_articles(get(f"{EUROPE_PMC}/{pmcid}/fullTextXML",tries=1,read_timeout=8)):
            text = xml_text(article)
            if matches_title(text,row["title"]):
                restored = save(row,text,"Europe PMC · "+pmcid)
                if restored:
                    return restored
        if row.get("status") == "downloaded_pmc_fulltext":
            raw = get(f"{BIOC}/{pmcid}/unicode",tries=1)
            bioc = json_response(raw)
            if isinstance(bioc,list):
                passages = [p.get("text","") for collection in bioc for doc in collection.get("documents",[])
                            for p in doc.get("passages",[]) if p.get("text")]
                restored = save(row,"\n\n".join(passages),"PMC BioC · "+pmcid)
                if restored:
                    return restored
    return {"id": row["id"], "status": "unresolved", "pmcid": pmcid, "doi": doi,
            "oa_locations_tried": len(tried)}


def batches(rows, size=20):
    for start in range(0,len(rows),size):
        yield rows[start:start+size]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--skip-pmc", action="store_true")
    parser.add_argument("--skip-attempted", action="store_true")
    parser.add_argument("--ids", type=Path)
    args = parser.parse_args()
    DESTINATION.mkdir(exist_ok=True)
    rows = list(corpus()[1].values())
    if args.ids:
        ids = set(args.ids.read_text(encoding="utf-8-sig").split())
        rows = [row for row in rows if row["id"] in ids]
    if args.limit:
        rows = rows[:args.limit]
    current = saved_texts()
    pending = [row for row in rows if not (current.get(row["id"]) or current.get(row.get("pmcid")))]
    print(f"Корпус: {len(rows)}; уже на диске: {len(rows)-len(pending)}; в очереди: {len(pending)}", flush=True)
    existing = len(rows)-len(pending)
    journal = DESTINATION / "restore.jsonl"
    if args.skip_attempted and journal.is_file():
        attempted = {json_response(line).get("id") for line in journal.read_text(encoding="utf-8").splitlines()}
        pending = [row for row in pending if row["id"] not in attempted]
    completed = set()
    counts = Counter()
    with journal.open("a", encoding="utf-8", buffering=1) as log:
        def record(result):
            log.write(json.dumps(result, ensure_ascii=False) + "\n")
            counts[result["status"]] += 1
            if result["status"] == "restored":
                completed.add(result["id"])
            if sum(counts.values()) % 50 == 0:
                print(dict(counts), flush=True)

        pmc = [row for row in pending if re.fullmatch(r"PMC\d+", row.get("pmcid") or "")]
        if not args.skip_pmc:
            with ThreadPoolExecutor(max_workers=min(args.workers, 4)) as pool:
                for results in pool.map(lambda batch: list(pmc_batch(batch)), batches(pmc)):
                    for result in results:
                        record(result)
        unresolved = [row for row in pending if row["id"] not in completed]
        print(f"После PMC: восстановлено {len(completed)}; поиск открытых копий: {len(unresolved)}", flush=True)
        with ThreadPoolExecutor(max_workers=6) as discovery, ThreadPoolExecutor(max_workers=args.workers) as downloads:
            pending_queries = {discovery.submit(list_locations,batch):batch for batch in batches(unresolved,25)}
            pending_downloads = []
            for query in as_completed(pending_queries):
                batch = pending_queries[query]
                options = query.result()
                pending_downloads.extend(downloads.submit(alternative,row,options[row["id"]]) for row in batch)
            for finished in as_completed(pending_downloads):
                record(finished.result())
    print(f"Доступно {existing+len(completed)} из {len(rows)}. {dict(counts)}", flush=True)


if __name__ == "__main__":
    main()

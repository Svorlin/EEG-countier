"""Retry transient NCBI PMC BioC download failures from saved status JSON."""
from pathlib import Path
import gzip
import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1] / "literature_search_2026-11-16"
STATUS = ROOT / "fulltext_download_status.json"
FULL = ROOT / "full_text"
HEAD = {
    "User-Agent": "EEGQualitySystematicReview/1.0 (research literature retrieval)",
    "Accept-Encoding": "gzip",
}


def download(entry):
    url = (
        "https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/"
        f"BioC_json/{urllib.parse.quote(entry['pmcid'])}/unicode"
    )
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers=HEAD)
            with urllib.request.urlopen(req, timeout=50) as response:
                raw = response.read()
            if raw[:2] == b"\x1f\x8b":
                raw = gzip.decompress(raw)
            try:
                obj = json.loads(raw)
            except json.JSONDecodeError:
                message = raw.decode("utf-8", errors="replace")[:500]
                if "No result can be found" in message:
                    entry.update(status="not_in_open_pmc_fulltext", error="PMC BioC has no open full text")
                    return entry
                raise ValueError(f"Non-JSON BioC response: {message[:160]}")
            if not obj or not obj[0].get("documents"):
                entry.update(status="not_in_open_pmc_fulltext", error="BioC response has no full-text document")
                return entry
            parts = []
            for document in obj[0]["documents"]:
                for passage in document.get("passages", []):
                    text = passage.get("text", "").strip()
                    if text:
                        parts.append(text)
            aid = entry["pmcid"].replace("/", "_")
            bio_path = FULL / f"{aid}.bioc.json"
            txt_path = FULL / f"{aid}.txt"
            bio_path.write_bytes(raw)
            text = "\n\n".join(parts)
            txt_path.write_text(text, encoding="utf-8")
            entry.update(
                status="downloaded_pmc_fulltext",
                path=str(bio_path.relative_to(ROOT)),
                text_path=str(txt_path.relative_to(ROOT)),
                sha256=hashlib.sha256(raw).hexdigest(),
                bytes=len(raw),
                text_chars=len(text),
                download_url=url,
                error="",
            )
            return entry
        except urllib.error.HTTPError as exc:
            if exc.code == 429 and attempt < 4:
                time.sleep(3 * (2**attempt))
                continue
            entry.update(status="retry_exhausted", error=f"HTTP {exc.code}")
            return entry
        except Exception as exc:
            entry.update(status="retry_exhausted", error=f"{type(exc).__name__}: {exc}")
            return entry
    return entry


def main():
    status = json.loads(STATUS.read_text(encoding="utf-8"))
    targets = [
        e for e in status["results"]
        if e.get("status") == "failed_or_not_open_fulltext"
        and "429" in e.get("error", "")
    ]
    print(f"Retrying {len(targets)} transient HTTP 429 failures, sequentially")
    for i, entry in enumerate(targets, 1):
        download(entry)
        if i % 10 == 0 or i == len(targets):
            STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"Retried {i}/{len(targets)}; latest status={entry['status']}", flush=True)
        time.sleep(0.5)
    from collections import Counter
    counts = Counter(e["status"] for e in status["results"])
    status["completed"] = len(status["results"])
    status["status_counts"] = dict(counts)
    status["retry_429_count"] = len(targets)
    STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dict(counts), ensure_ascii=False))


if __name__ == "__main__":
    main()

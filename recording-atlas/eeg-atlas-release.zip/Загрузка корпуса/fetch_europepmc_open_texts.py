"""Look for additional openly licensed Europe PMC full texts by PubMed ID."""
import csv
import hashlib
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "literature_search_2026-11-16"
STATUS_PATH = ROOT / "fulltext_download_status.json"
META_PATH = ROOT / "europepmc_oa_candidates.json"
PROVENANCE_PATH = ROOT / "europepmc_api_provenance.json"
FULL = ROOT / "full_text_europepmc"
FULL.mkdir(exist_ok=True)
HEAD = {"User-Agent": "EEGQualityLiteratureReview/1.0 (OA literature retrieval)", "Accept-Encoding": "gzip"}


def fetch(url, data=None, tries=5):
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, data=data, headers=HEAD, method="POST" if data else "GET")
            with urllib.request.urlopen(req, timeout=50) as response:
                raw = response.read()
            if raw[:2] == b"\x1f\x8b":
                import gzip
                raw = gzip.decompress(raw)
            return raw
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504) and attempt + 1 < tries:
                time.sleep(min(30, 2**attempt * 2))
                continue
            raise


def full_text_result(pmid, pmcid, license_value=""):
    url = f"https://www.ebi.ac.uk/europepmc/webservices/rest/{urllib.parse.quote(pmcid)}/fullTextXML"
    try:
        raw = fetch(url)
        root = ET.fromstring(raw)
        paragraphs = []
        for node in root.iter():
            if node.tag.rsplit("}", 1)[-1] in {"title", "label", "p", "caption"}:
                text = " ".join("".join(node.itertext()).split())
                if text:
                    paragraphs.append(text)
        text = "\n\n".join(paragraphs)
        if len(text) < 1500 or root.tag.rsplit("}", 1)[-1] != "article":
            return None
        xml_path = FULL / f"PMID{pmid}.xml"
        txt_path = FULL / f"PMID{pmid}.txt"
        xml_path.write_bytes(raw)
        txt_path.write_text(text, encoding="utf-8")
        return {"pmid": pmid, "status": "downloaded_europepmc_oa_fulltext", "path": str(xml_path.relative_to(ROOT)), "text_path": str(txt_path.relative_to(ROOT)), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "text_chars": len(text), "download_url": url, "openalex_source": "Europe PMC", "openalex_license": license_value}
    except Exception:
        return None


def main():
    bibliography = json.loads((ROOT / "bibliography.json").read_text(encoding="utf-8"))
    statuses = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
    by_pmid = {x["pmid"]: x for x in statuses["results"]}
    remaining = [r for r in bibliography if not by_pmid[r["pmid"]]["status"].startswith("downloaded_") and r.get("pubmed_record_type") != "book_chapter_or_book_record"]
    candidate_rows = {}
    response_hashes = []
    errors = []
    for start in range(0, len(remaining), 100):
        batch = remaining[start:start + 100]
        query = "EXT_ID:(" + " OR ".join(r["pmid"] for r in batch) + ") AND OPEN_ACCESS:Y"
        url = "https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urllib.parse.urlencode({"query": query, "format": "json", "resultType": "core", "pageSize": 100})
        try:
            raw = fetch(url)
            response_hashes.append(hashlib.sha256(raw).hexdigest())
            result = json.loads(raw).get("resultList", {}).get("result", [])
            for record in result:
                pmid = record.get("pmid")
                pmcid = record.get("pmcid") or ""
                if pmid and pmcid and record.get("isOpenAccess") == "Y":
                    candidate_rows[pmid] = {"pmid": pmid, "pmcid": pmcid, "doi": record.get("doi", ""), "title": record.get("title", ""), "license": record.get("license", ""), "has_pdf": record.get("hasPDF", "N"), "full_text_urls": record.get("fullTextUrlList", {}).get("fullTextUrl", [])}
        except Exception as exc:
            errors.append({"batch_start": start, "error": f"{type(exc).__name__}: {exc}"})
        if (start // 100 + 1) % 10 == 0 or start + 100 >= len(remaining):
            META_PATH.write_text(json.dumps({"candidates": candidate_rows, "errors": errors}, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"Europe PMC metadata {min(start + 100, len(remaining))}/{len(remaining)}; OA full-text candidates {len(candidate_rows)}", flush=True)
        time.sleep(0.35)
    META_PATH.write_text(json.dumps({"candidates": candidate_rows, "errors": errors}, ensure_ascii=False, indent=2), encoding="utf-8")
    PROVENANCE_PATH.write_text(json.dumps({"api": "Europe PMC REST search + fullTextXML", "search_query_template": "EXT_ID:(PMID OR ...) AND OPEN_ACCESS:Y", "records_checked": len(remaining), "oa_fulltext_candidates": len(candidate_rows), "response_sha256": response_hashes, "errors": errors}, ensure_ascii=False, indent=2), encoding="utf-8")

    downloaded = 0
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(full_text_result, pmid, rec["pmcid"], rec["license"]): pmid for pmid, rec in candidate_rows.items() if pmid in by_pmid and not by_pmid[pmid]["status"].startswith("downloaded_")}
        for i, future in enumerate(as_completed(futures), 1):
            result = future.result()
            pmid = futures[future]
            if result:
                by_pmid[pmid].update(result)
                downloaded += 1
            if i % 25 == 0 or i == len(futures):
                statuses["results"] = list(by_pmid.values())
                STATUS_PATH.write_text(json.dumps(statuses, ensure_ascii=False, indent=2), encoding="utf-8")
                print(f"Europe PMC full text {i}/{len(futures)}; new downloads {downloaded}", flush=True)
            time.sleep(0.2)

    statuses["results"] = list(by_pmid.values())
    counts = Counter(x["status"] for x in statuses["results"])
    statuses["status_counts"] = dict(counts)
    STATUS_PATH.write_text(json.dumps(statuses, ensure_ascii=False, indent=2), encoding="utf-8")
    for row in bibliography:
        row["full_text_status"] = by_pmid[row["pmid"]]["status"]
        row["full_text_path"] = by_pmid[row["pmid"]].get("path", "")
        row["full_text_text_path"] = by_pmid[row["pmid"]].get("text_path", "")
    (ROOT / "bibliography.json").write_text(json.dumps(bibliography, ensure_ascii=False), encoding="utf-8")
    with (ROOT / "bibliography.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(bibliography[0]))
        writer.writeheader()
        writer.writerows(bibliography)
    print(json.dumps({"new_europepmc_downloads": downloaded, "oa_candidates": len(candidate_rows), "status_counts": dict(counts)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

"""Recover published article files into the local EEG corpus."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
from http.client import HTTPException
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from urllib.error import URLError
from urllib.parse import quote, urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
PDF=ROOT/"Корпус PDF"
OTHER=ROOT/"Корпус оригиналы"
REPORT=OTHER/"Статус оригиналов.jsonl"
BUCKET="https://pmc-oa-opendata.s3.amazonaws.com/"
MAX_BYTES=64*1024*1024


def read_url(url,limit=MAX_BYTES):
    url=quote(url,safe=":/?&%=+#;,@[]!$()*")
    request=Request(url,headers={"User-Agent":"EEG Atlas research corpus/1.0",
                                "Accept":"application/pdf, application/xml, text/html, */*"})
    with urlopen(request,timeout=18) as response:
        body=response.read(limit+1)
        return (body,response.geturl()) if len(body)<=limit else (b"",url)


def write_original(aid,ext,data):
    folder=PDF if ext=="pdf" else OTHER
    path=folder/(aid+"."+ext)
    with tempfile.NamedTemporaryFile(dir=folder,delete=False) as out:
        partial=Path(out.name)
        out.write(data)
    try:
        partial.replace(path)
    finally:
        partial.unlink(missing_ok=True)
    return str(path.relative_to(ROOT))


def matches_pdf(data,row):
    tool=shutil.which("pdftotext")
    if not tool:
        return False
    try:
        page=subprocess.run([tool,"-f","1","-l","1","-enc","UTF-8","-","-"],input=data,
                            capture_output=True,timeout=15,check=True,
                            creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)).stdout.decode("utf8",errors="replace")
    except (OSError,subprocess.SubprocessError):
        return False
    normalize=lambda value:re.sub(r"\W+","",value.casefold())
    title=normalize(row["title"])
    doi=row["doi"].strip().casefold()
    return (len(title)>=24 and title in normalize(page)) or bool(doi and doi in page.casefold())


def recover(row, alternatives=(), search_pmc=True):
    aid=row["id"]
    for ext,folder in (("pdf",PDF),("html",OTHER),("xml",OTHER)):
        path=folder/(aid+"."+ext)
        if path.is_file() and path.stat().st_size>500:
            return {"id":aid,"format":ext,"file":str(path.relative_to(ROOT)),"status":"existing"}
    pmc=row["pmcid"]
    found=[]
    if search_pmc and re.fullmatch(r"PMC[0-9]+",pmc):
        try:
            listing,_=read_url(BUCKET+"?"+urlencode({"list-type":2,"prefix":pmc+".","max-keys":1000}),4*1024*1024)
            for node in ET.fromstring(listing).findall(".//{*}Key"):
                m=re.fullmatch(rf"{pmc}\.([0-9]+)/{pmc}\.\1\.(pdf|xml)",node.text or "")
                if m:
                    found.append((m[2],int(m[1]),BUCKET+quote(node.text)))
        except (OSError,URLError,ET.ParseError):
            pass
    candidates=[(ext,url) for ext,_,url in sorted(found,key=lambda x:(x[0]!="pdf",-x[1])) if ext=="pdf"]
    source=row["source"].strip()
    if source.startswith("https://") and urlsplit(source).hostname not in {"doi.org","dx.doi.org"}:
        candidates.append(("",source))
    candidates.extend(("",url) for url in alternatives)
    candidates.extend((ext,url) for ext,_,url in sorted(found,key=lambda x:-x[1]) if ext=="xml")
    queue=list(dict.fromkeys(candidates))
    visited=set()
    for expected,url in queue:
        if url in visited or len(visited)>=16:
            continue
        visited.add(url)
        try:
            data,resolved=read_url(url)
        except (OSError,URLError,ValueError,HTTPException):
            continue
        ext=""
        if b"%PDF-" in data[:1024] and b"%%EOF" in data[-16384:]:
            if expected=="linked-pdf" and not matches_pdf(data,row):
                continue
            ext="pdf"
        elif expected=="xml" and re.search(rb"<article(?:\s|>)",data[:16000]):
            ext="xml"
        elif not expected and row["status"]=="full_text" and len(data)>12000:
            probe=data.lower()
            if (b"<article" in probe or b"citation_title" in probe) and (b"methods" in probe or b"introduction" in probe) and not any(x in probe[:9000] for x in (b"captcha",b"access denied",b"just a moment")):
                from html import unescape
                from html.parser import HTMLParser
                class ArticleParser(HTMLParser):
                    def __init__(self):
                        super().__init__(); self.title=""; self.text=[]; self.pdfs=[]
                    def handle_starttag(self,tag,attrs):
                        value=dict(attrs)
                        if tag=="meta" and value.get("name","").lower()=="citation_title":
                            self.title=value.get("content","")
                        if tag=="meta" and value.get("name","").lower()=="citation_pdf_url":
                            self.pdfs.insert(0,value.get("content",""))
                        if tag=="a" and value.get("href"):
                            href=value["href"]
                            if re.search(r"(?i)(?:\.pdf(?:$|[?#])|/file/|/download(?:$|/)|/clanak/)",href):
                                self.pdfs.append(href)
                    def handle_data(self,text):
                        self.text.append(text)
                def normalized(text):
                    return re.sub(r"\W+","",unescape(text).casefold())
                parser=ArticleParser()
                parser.feed(data.decode("utf8",errors="replace"))
                title=normalized(row["title"])
                for address in dict.fromkeys(parser.pdfs[:6]):
                    address=urljoin(resolved,address)
                    if address.startswith("https://") and address not in visited:
                        queue.append(("linked-pdf",address))
                visible=normalized(" ".join(parser.text))
                source_text=ROOT/"Корпус полные тексты"/(aid+".txt")
                reference=normalized(source_text.read_text(encoding="utf-8-sig",errors="replace")) if source_text.is_file() else ""
                anchors=[reference[int(len(reference)*fraction):int(len(reference)*fraction)+65]
                         for fraction in (.20,.35,.50,.65,.75)] if len(reference)>1000 else []
                if title and (title==normalized(parser.title) or title in visible) and sum(a in visible for a in anchors)>=2:
                    ext="html"
        if ext:
            return {"id":aid,"format":ext,"file":write_original(aid,ext,data),"url":resolved,"status":"restored"}
    return {"id":aid,"status":"unavailable","pmcid":pmc,"doi":row["doi"]}


def main():
    from collections import Counter
    import time
    PDF.mkdir(exist_ok=True)
    OTHER.mkdir(exist_ok=True)
    with (ROOT/"Корпус полные тексты"/"Статус восстановления.csv").open(encoding="utf-8-sig",newline="") as source:
        rows=list(csv.DictReader(source))
    counts=Counter()
    started=time.monotonic()
    with REPORT.open("w",encoding="utf-8") as report,ThreadPoolExecutor(max_workers=24) as pool:
        futures={pool.submit(recover,row):row for row in rows}
        for number,future in enumerate(as_completed(futures),1):
            try:
                result=future.result()
            except Exception as exc:
                result={"id":futures[future]["id"],"status":"error","error":str(exc)}
            report.write(json.dumps(result,ensure_ascii=False)+"\n")
            counts[result.get("format",result["status"])]+=1
            if number%100==0 or number==len(rows):
                report.flush()
                print(number,len(rows),dict(counts),round(time.monotonic()-started,1),flush=True)


def recover_missing(only_full_text=False):
    from collections import Counter
    from fetch_alternative_fulltext import batch_api, clean_doi, oa_locations
    rows={row["id"]:row for row in csv.DictReader(
        (ROOT/"Корпус полные тексты"/"Статус восстановления.csv").read_text(encoding="utf-8-sig").splitlines())}
    previous={item["id"]:item for line in REPORT.read_text(encoding="utf-8").splitlines()
              if (item:=json.loads(line))}
    archive_manifest=OTHER/"Из локальных архивов.jsonl"
    if archive_manifest.is_file():
        for line in archive_manifest.read_text(encoding="utf-8").splitlines():
            item=json.loads(line)
            aid=item["id"]
            current=previous.get(aid,{})
            if current.get("format")!="pdf" or current.get("status")=="existing":
                previous[aid]=item
    fixes=OTHER/"Неполные загрузки"
    for correction in fixes.glob("CORPUS_*.json"):
        item=json.loads(correction.read_text(encoding="utf8"))
        if item.get("format") or (previous.get(item["id"],{}).get("file")
                                  and not (ROOT/previous[item["id"]]["file"]).is_file()):
            previous[item["id"]]=item
    missing=[rows[aid] for aid,item in previous.items() if item["status"] in {"unavailable","error"}
             and (not only_full_text or rows[aid]["status"]=="full_text")]
    lookup={clean_doi(row["doi"]):[] for row in missing if clean_doi(row["doi"])}
    dois=list(lookup)
    for offset in range(0,len(dois),35):
        try:
            matches,_=batch_api("doi:"+"|".join(dois[offset:offset+35]))
        except (OSError,ValueError):
            continue
        for match in matches:
            doi=clean_doi(match.get("doi"))
            if doi in lookup:
                lookup[doi]=[entry["url"] for entry in oa_locations(match)
                             if entry["url"].startswith("https://")][:6]
    eligible=[row for row in missing if lookup.get(clean_doi(row["doi"]))]
    print(f"OpenAlex: {len(eligible)} статей с адресами открытых копий",flush=True)
    changes=Counter()
    with ThreadPoolExecutor(max_workers=12) as pool:
        futures={pool.submit(recover,row,lookup[clean_doi(row["doi"])],False):row["id"] for row in eligible}
        for number,future in enumerate(as_completed(futures),1):
            try:
                item=future.result()
            except (OSError,ValueError):
                continue
            if item.get("format"):
                previous[item["id"]]=item
                changes[item["format"]]+=1
            if number%50==0 or number==len(eligible):
                print(f"OpenAlex {number}/{len(eligible)}",dict(changes),flush=True)
    temp=REPORT.with_suffix(".tmp")
    with temp.open("w",encoding="utf-8") as out:
        for item in sorted(previous.values(),key=lambda item:item["id"]):
            out.write(json.dumps(item,ensure_ascii=False)+"\n")
    temp.replace(REPORT)
    print("Итог",dict(Counter(item.get("format",item["status"]) for item in previous.values())),flush=True)


def review_landing_pages():
    rows={row["id"]:row for row in csv.DictReader(
        (ROOT/"Корпус полные тексты"/"Статус восстановления.csv").read_text(encoding="utf-8-sig").splitlines())}
    previous={item["id"]:item for line in REPORT.read_text(encoding="utf-8").splitlines()
              if (item:=json.loads(line))}
    items=[item for item in previous.values() if item.get("format")=="html" and item.get("status")=="restored"]
    snapshots=OTHER/"Страницы публикаций"
    snapshots.mkdir(exist_ok=True)

    def check(item):
        aid=item["id"]
        path=OTHER/(aid+".html")
        snapshot=snapshots/path.name
        if not path.is_file() and not snapshot.is_file():
            return recover(rows[aid],[item.get("url","")],False)
        from html.parser import HTMLParser
        from html import unescape
        class Visible(HTMLParser):
            def __init__(self):
                super().__init__()
                self.text=[]
            def handle_data(self,text):
                self.text.append(text)
        def normalized(value):
            return re.sub(r"\W+","",unescape(value).casefold())
        parser=Visible()
        parser.feed((path if path.is_file() else snapshot).read_text(encoding="utf8",errors="replace"))
        visible=normalized(" ".join(parser.text))
        text=ROOT/"Корпус полные тексты"/(aid+".txt")
        reference=normalized(text.read_text(encoding="utf-8-sig")) if text.is_file() else ""
        anchors=[reference[int(len(reference)*f):int(len(reference)*f)+65] for f in (.2,.35,.5,.65,.75)] if len(reference)>1000 else []
        if sum(part in visible for part in anchors)>=2:
            return item
        if path.is_file():
            path.replace(snapshot)
        result=recover(rows[aid],[item.get("url","")],False)
        if not result.get("format"):
            result["landing_page"]=str(snapshot.relative_to(ROOT))
        return result

    with ThreadPoolExecutor(max_workers=10) as pool:
        for result in pool.map(check,items):
            previous[result["id"]]=result
    temp=REPORT.with_suffix(".tmp")
    with temp.open("w",encoding="utf8") as out:
        for result in sorted(previous.values(),key=lambda item:item["id"]):
            out.write(json.dumps(result,ensure_ascii=False)+"\n")
    temp.replace(REPORT)
    print("Проверены страницы публикаций:",len(items),flush=True)


def restore_figures():
    """Restore graphics referenced by the original JATS files in their native directory layout."""
    items=[]
    for line in REPORT.read_text(encoding="utf-8").splitlines():
        try:
            item=json.loads(line)
        except ValueError:
            continue
        if item.get("format")=="xml" and item.get("url","").startswith(BUCKET):
            items.append(item)

    def figures(item):
        aid=item["id"]
        xml=OTHER/(aid+".xml")
        try:
            root=ET.parse(xml).getroot()
        except (ET.ParseError,OSError):
            return 0
        prefix=item["url"].rsplit("/",1)[0]+"/"
        target=OTHER/aid
        result=0
        for node in root.findall(".//{*}fig//{*}graphic"):
            name=node.get("{http://www.w3.org/1999/xlink}href","")
            if not re.fullmatch(r"[A-Za-z0-9_.-]+\.(?:jpe?g|png|gif|tiff?|svg)",name,re.I):
                continue
            path=target/name
            if path.is_file():
                result+=1
                continue
            try:
                body,_=read_url(prefix+quote(name),20*1024*1024)
                if not body or body[:100].lstrip().lower().startswith((b"<!doctype html",b"<html")):
                    continue
                target.mkdir(exist_ok=True)
                path.write_bytes(body)
                result+=1
            except (OSError,ValueError):
                continue
        return result

    images=0
    with ThreadPoolExecutor(max_workers=12) as pool:
        for n,count in enumerate(pool.map(figures,items),1):
            images+=count
            if n%50==0 or n==len(items):
                print(f"Иллюстрации XML: {n}/{len(items)}, файлов {images}",flush=True)


if __name__=="__main__":
    import sys
    if "--figures" in sys.argv:
        restore_figures()
    elif "--review-html" in sys.argv:
        review_landing_pages()
    elif "--missing-openalex" in sys.argv:
        recover_missing("--atlas-only" in sys.argv)
    else:
        main()

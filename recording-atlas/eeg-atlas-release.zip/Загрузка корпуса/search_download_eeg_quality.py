"""Reproducible OLD801-adjacent PubMed search + lawful PMC OA BioC downloads."""
from pathlib import Path
import urllib.parse,urllib.request,xml.etree.ElementTree as ET,json,csv,time,hashlib,datetime,re,sys,html

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'literature_search_2026-11-16';OUT.mkdir(exist_ok=True)
FULL=OUT/'full_text';FULL.mkdir(exist_ok=True)
NOW='2026/11/16'
START='1985/01/01'
QUAL='("signal quality"[Title/Abstract] OR "EEG quality"[Title/Abstract] OR artifact*[Title/Abstract] OR artefact*[Title/Abstract] OR denois*[Title/Abstract] OR preprocess*[Title/Abstract] OR "signal cleaning"[Title/Abstract] OR "bad channel"[Title/Abstract])'
EEG='(EEG[Title/Abstract] OR electroencephalogra*[Title/Abstract] OR "Electroencephalography"[MeSH Terms])'
DATE=f'("{START}"[Date - Publication] : "{NOW}"[Date - Publication])'
LANG='English[Language]'
QUERIES=[
 {'id':'primary','purpose':'Broad eligible corpus; method focus is applied during screening, so ICA/ML are not mandatory search terms.','term':f'{EEG} AND {QUAL} AND {DATE} AND {LANG}'},
 {'id':'ica_analytical','purpose':'Supplementary analytical-method slice; merged into broad corpus, not an eligibility filter.','term':f'{EEG} AND {QUAL} AND ("independent component analysis"[Title/Abstract] OR ICA[Title/Abstract] OR "blind source separation"[Title/Abstract] OR SOBI[Title/Abstract]) AND {DATE} AND {LANG}'},
 {'id':'machine_learning','purpose':'Supplementary ML slice; merged into broad corpus, not an eligibility filter.','term':f'{EEG} AND {QUAL} AND ("machine learning"[Title/Abstract] OR "deep learning"[Title/Abstract] OR neural network*[Title/Abstract] OR classifier*[Title/Abstract] OR "support vector machine"[Title/Abstract] OR SVM[Title/Abstract]) AND {DATE} AND {LANG}'}]
BASE='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/'
HEAD={'User-Agent':'EEGQualityLiteratureReview/1.0 (research; contact not provided)','Accept-Encoding':'gzip'}
def fetch(url):
 req=urllib.request.Request(url,headers=HEAD)
 with urllib.request.urlopen(req,timeout=50) as r:return r.read()
def api(endpoint,params):
 return fetch(BASE+endpoint+'?'+urllib.parse.urlencode(params))
def esearch(q):
 raw=api('esearch.fcgi',{'db':'pubmed','term':q,'retmax':0,'retmode':'json','tool':'eeg_quality_review'})
 x=json.loads(raw);e=x['esearchresult'];return int(e['count']),e.get('querytranslation',''),hashlib.sha256(raw).hexdigest()
def get_ids(q,count):
 ids=[]
 for start in range(0,count,10000):
  raw=api('esearch.fcgi',{'db':'pubmed','term':q,'retstart':start,'retmax':min(10000,count-start),'retmode':'json','tool':'eeg_quality_review'})
  ids.extend(json.loads(raw)['esearchresult']['idlist']);time.sleep(.36)
 return ids
def xml_value(node,path):
 x=node.find(path);return ''.join(x.itertext()).strip() if x is not None else ''
def parse_pubmed(raw):
 root=ET.fromstring(raw);rows=[]
 for a in root.findall('.//PubmedArticle'):
  pmid=xml_value(a,'.//PMID');title=xml_value(a,'.//ArticleTitle');abstract=' '.join(''.join(x.itertext()).strip() for x in a.findall('.//Abstract/AbstractText'))
  doi='';pmcid='';journal=xml_value(a,'.//Journal/Title');year=xml_value(a,'.//JournalIssue/PubDate/Year') or xml_value(a,'.//ArticleDate/Year')
  for aid in a.findall('.//PubmedData/ArticleIdList/ArticleId'):
   if aid.get('IdType')=='doi':doi=aid.text or ''
   if aid.get('IdType')=='pmc':pmcid=aid.text or ''
  if not year:
   med=xml_value(a,'.//JournalIssue/PubDate/MedlineDate');m=re.search(r'\b(19|20)\d{2}\b',med);year=m.group(0) if m else ''
  authors=[]
  for au in a.findall('.//AuthorList/Author'):
   name=' '.join(filter(None,[xml_value(au,'ForeName'),xml_value(au,'LastName')]))
   if name:authors.append(name)
  rows.append({'pmid':pmid,'pmcid':pmcid,'doi':doi,'title':title,'year':year,'journal':journal,'authors':'; '.join(authors),'abstract':abstract,'pubmed_url':f'https://pubmed.ncbi.nlm.nih.gov/{pmid}/','pmc_url':f'https://pmc.ncbi.nlm.nih.gov/articles/{pmcid}/' if pmcid else ''})
 return rows
def main():
 log={'search_date_local':'2026-11-16','timezone':'Europe/Moscow','database':'PubMed / NCBI E-utilities','date_range':{'from':'1985-01-01','through':'2026-11-16'},'language':'English','queries':[],'deduplication':'PMID primary key; DOI and normalized title retained for later cross-source deduplication','eligibility':'EEG signal quality/processing: artifact detection, rejection, correction, denoising, preprocessing, channel quality. ICA/BSS and ML are analytic slices, not mandatory for broad query. EEG must be signal-quality context; downstream-only clinical/BCI study is not automatically eligible.','full_text_policy':'Download available PMC full text through NCBI BioC; retain bibliographic record/abstract/link and mark full text unavailable otherwise. No access-control circumvention.'}
 allids=set();query_ids={}
 for q in QUERIES:
  n,translation,digest=esearch(q['term']);ids=get_ids(q['term'],n);query_ids[q['id']]=ids;allids.update(ids)
  log['queries'].append({**q,'exact_query':q['term'],'count_at_search':n,'ids_retrieved':len(ids),'pubmed_query_translation':translation,'esearch_response_sha256':digest,'search_complete':len(ids)==n})
 (OUT/'search_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
 ids=sorted(allids,key=int);(OUT/'pmid_union.json').write_text(json.dumps({'pmids':ids,'count':len(ids)},indent=2),encoding='utf-8')
 rows=[]
 for i in range(0,len(ids),200):
  raw=api('efetch.fcgi',{'db':'pubmed','id':','.join(ids[i:i+200]),'rettype':'abstract','retmode':'xml','tool':'eeg_quality_review'});rows.extend(parse_pubmed(raw));time.sleep(.36)
 seen=set();unique=[]
 for x in rows:
  if x['pmid'] in seen:continue
  seen.add(x['pmid']);unique.append(x)
 queryset={k:set(v) for k,v in query_ids.items()}
 for x in unique:x['query_slices']=';'.join(k for k,v in queryset.items() if x['pmid'] in v);x['full_text_status']='not_attempted'
 with (OUT/'bibliography.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(unique[0]) if unique else ['pmid']);w.writeheader();w.writerows(unique)
 (OUT/'bibliography.json').write_text(json.dumps(unique,ensure_ascii=False),encoding='utf-8')
 (OUT/'efetch_provenance.json').write_text(json.dumps({'records':len(rows),'unique_pmids':len(unique),'batch_size':200,'efetch_response_sha256':[hashlib.sha256(api('efetch.fcgi',{'db':'pubmed','id':','.join(ids[i:i+200]),'rettype':'abstract','retmode':'xml','tool':'eeg_quality_review'})).hexdigest() for i in range(0,0,200)]},indent=2),encoding='utf-8')
 results=[]
 for i,x in enumerate(unique):
  item={'pmid':x['pmid'],'pmcid':x['pmcid'],'status':'no_pmcid','path':'','sha256':'','bytes':0,'error':''}
  if x['pmcid']:
   url=f"https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_json/{urllib.parse.quote(x['pmcid'])}/unicode"
   try:
    raw=fetch(url);obj=json.loads(raw)
    if not obj or not obj[0].get('documents'):raise ValueError('BioC response has no full-text document')
    aid=x['pmcid'].replace('/','_');dest=FULL/(aid+'.bioc.json');dest.write_bytes(raw)
    docs=obj[0]['documents'];parts=[]
    for d in docs:
     for p in d.get('passages',[]):
      txt=p.get('text','').strip()
      if txt:parts.append(txt)
    text='\n\n'.join(parts);txtpath=FULL/(aid+'.txt');txtpath.write_text(text,encoding='utf-8')
    item.update(status='downloaded_pmc_fulltext',path=str(dest.relative_to(OUT)),text_path=str(txtpath.relative_to(OUT)),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),text_chars=len(text),download_url=url)
   except Exception as e:item.update(status='failed_or_not_open_fulltext',error=str(e),download_url=url)
  results.append(item)
  if i%100==0:
   (OUT/'fulltext_download_status.json').write_text(json.dumps({'completed':i+1,'total':len(unique),'results':results},ensure_ascii=False,indent=2),encoding='utf-8');print('Fulltext',i+1,'/',len(unique),flush=True)
  time.sleep(.36)
 (OUT/'fulltext_download_status.json').write_text(json.dumps({'completed':len(unique),'total':len(unique),'results':results},ensure_ascii=False,indent=2),encoding='utf-8')
 by={x['pmid']:x for x in results}
 for x in unique:x['full_text_status']=by[x['pmid']]['status'];x['full_text_path']=by[x['pmid']].get('path','')
 (OUT/'bibliography.json').write_text(json.dumps(unique,ensure_ascii=False),encoding='utf-8')
 with (OUT/'bibliography.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(unique[0]));w.writeheader();w.writerows(unique)
 log['results']={'query_union_unique_pmids':len(unique),'full_text_downloaded':sum(x['status']=='downloaded_pmc_fulltext' for x in results),'full_text_unavailable_or_failed':sum(x['status']!='downloaded_pmc_fulltext' for x in results),'full_text_failures':{x['pmid']:x['error'] for x in results if x['error']}}
 log['completed_at_local']=datetime.datetime.now().astimezone().isoformat()
 (OUT/'search_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(log['results'],ensure_ascii=False,indent=2))
if __name__=='__main__':main()

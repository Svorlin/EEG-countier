"""Search OpenAIRE for additional open repository/journal copies by DOI and PMID."""
import csv
import gzip
import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import fetch_alternative_fulltext as fetcher

ROOT = fetcher.ROOT
STATUS_PATH = fetcher.STATUS_PATH
META_PATH = ROOT / "openaire_open_locations.json"
PROVENANCE_PATH = ROOT / "openaire_api_provenance.json"
BASE = "https://api.openaire.eu/graph/v4/research-products?"
FIELDS = "id,mainTitle,pids,instances,links,bestAccessRight"
HEADERS = {"User-Agent": "EEGQualityLiteratureReview/1.0 (open repository retrieval)", "Accept-Encoding": "gzip"}


def request_json(url, retries=6):
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=60) as response:
                raw = response.read()
            if raw[:2] == b"\x1f\x8b":
                raw = gzip.decompress(raw)
            return raw, json.loads(raw)
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504) and attempt + 1 < retries:
                time.sleep(min(60, 2**attempt * 2))
                continue
            raise


def clean_doi(value):
    return (value or "").strip().lower().removeprefix("https://doi.org/").removeprefix("http://doi.org/")


def open_urls(record):
    locations = []
    best = (record.get("bestAccessRight") or {}).get("label", "").lower()
    for inst in record.get("instances") or []:
        access = ((inst.get("accessRight") or {}).get("label") or best).lower()
        if access not in ("open", "open access", "oa"):
            continue
        source = (inst.get("hostedBy") or {}).get("value", "")
        for url in inst.get("urls") or []:
            if not url.startswith("http"):
                continue
            low = url.lower()
            if any(host in low for host in ("doi.org/", "dx.doi.org/", "pubmed.ncbi.nlm.nih.gov/", "ncbi.nlm.nih.gov/pmc/")):
                continue
            locations.append({"url": url, "kind": "pdf" if ".pdf" in low else "landing", "source_name": source, "source_type": "OpenAIRE instance", "license": inst.get("license"), "version": inst.get("type"), "is_oa": True, "access_right": access})
    for link in record.get("links") or []:
        url = link.get("url") or link.get("href") or ""
        access = (link.get("accessRight") or {}).get("label", "").lower()
        if not url.startswith("http") or access not in ("open", "open access", "oa"):
            continue
        if any(host in url.lower() for host in ("doi.org/", "pubmed.ncbi.nlm.nih.gov/", "ncbi.nlm.nih.gov/pmc/")):
            continue
        locations.append({"url": url, "kind": "pdf" if ".pdf" in url.lower() else "landing", "source_name": link.get("title", "OpenAIRE link"), "source_type": link.get("type", ""), "license": link.get("license"), "version": "", "is_oa": True, "access_right": access})
    seen = set()
    result = []
    for loc in locations:
        if loc["url"] not in seen:
            seen.add(loc["url"])
            result.append(loc)
    result.sort(key=lambda x: (x["kind"] != "pdf", x["source_type"] != "repository"))
    return result


def main():
    rows = json.loads((ROOT / "bibliography.json").read_text(encoding="utf-8"))
    statuses = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
    by_pmid = {x["pmid"]: x for x in statuses["results"]}
    unresolved = [r for r in rows if not by_pmid[r["pmid"]]["status"].startswith("downloaded_") and r.get("pubmed_record_type") != "book_chapter_or_book_record"]
    by_doi = {clean_doi(r.get("doi", "")): r["pmid"] for r in unresolved if r.get("doi")}
    by_id = {r["pmid"]: r["pmid"] for r in unresolved if not r.get("doi")}
    query_batches = []
    records_by_pmid = {}
    hashes = []
    for kind, values, field in (("doi", sorted(by_doi), "ids.doi"), ("pmid", sorted(by_id, key=int), "ids.pmid")):
        for start in range(0, len(values), 40):
            batch = values[start:start + 40]
            query = "type:publication," + field + ":" + "|".join(batch)
            params = {"filter": query, "page_size": 100, "select": FIELDS}
            url = BASE + urllib.parse.urlencode(params)
            try:
                raw, obj = request_json(url)
                hashes.append(hashlib.sha256(raw).hexdigest())
                for record in obj.get("results", []):
                    for pid in record.get("pids") or []:
                        scheme, value = pid.get("scheme", "").lower(), pid.get("value", "")
                        if scheme == "doi" and clean_doi(value) in by_doi:
                            records_by_pmid[by_doi[clean_doi(value)]] = record
                        elif scheme == "pmid" and value in by_id:
                            records_by_pmid[value] = record
            except Exception as exc:
                hashes.append(f"ERROR:{type(exc).__name__}:{exc}")
            query_batches.append({"batch": len(query_batches) + 1, "identifier_type": kind, "query": query, "identifiers": batch})
            if len(query_batches) % 10 == 0 or start + 40 >= len(values):
                print(f"OpenAIRE searches {len(query_batches)} batches; matched {len(records_by_pmid)} records", flush=True)
            time.sleep(0.4)

    candidate_map = {}
    for pmid, record in records_by_pmid.items():
        locs = open_urls(record)
        candidate_map[pmid] = {"openaire_id": record.get("id", ""), "title": record.get("mainTitle", ""), "best_access_right": record.get("bestAccessRight"), "locations": locs}
    META_PATH.write_text(json.dumps(candidate_map, ensure_ascii=False, indent=2), encoding="utf-8")
    PROVENANCE_PATH.write_text(json.dumps({"api": "OpenAIRE Graph API v4 research-products", "records_checked": len(unresolved), "records_matched": len(records_by_pmid), "records_with_open_urls": sum(bool(x["locations"]) for x in candidate_map.values()), "exact_query_batches": query_batches, "response_sha256_or_errors": hashes}, ensure_ascii=False, indent=2), encoding="utf-8")

    tasks = [(rows_by_pmid, candidate_map[pmid]) for pmid, rows_by_pmid in ((r["pmid"], r) for r in unresolved) if pmid in candidate_map and candidate_map[pmid]["locations"]]
    downloaded = 0
    def attempt(task):
        row, meta = task
        for loc in meta["locations"]:
            result = fetcher.save_download(row["pmid"], loc)
            if result:
                result.update(status="downloaded_openaire_open_fulltext", alternative_source="OpenAIRE", openalex_source=loc.get("source_name", ""), openalex_source_type=loc.get("source_type", ""), openalex_license=loc.get("license"), openalex_version=loc.get("version", ""))
                return result
            time.sleep(0.25)
        return {"pmid": row["pmid"], "status": "openaire_open_location_not_retrieved", "error": "OpenAIRE marked the instance OPEN, but no URL returned a validated full text", "openaire_id": meta.get("openaire_id", ""), "openaire_locations": meta["locations"]}

    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(attempt, task): task[0]["pmid"] for task in tasks}
        for i, future in enumerate(as_completed(futures), 1):
            result = future.result()
            pmid = result["pmid"]
            by_pmid[pmid].update(result)
            downloaded += result["status"] == "downloaded_openaire_open_fulltext"
            if i % 25 == 0 or i == len(futures):
                statuses["results"] = list(by_pmid.values())
                STATUS_PATH.write_text(json.dumps(statuses, ensure_ascii=False, indent=2), encoding="utf-8")
                print(f"OpenAIRE text retrieval {i}/{len(tasks)}; downloads {downloaded}", flush=True)
    statuses["results"] = list(by_pmid.values())
    counts = Counter(x["status"] for x in statuses["results"])
    statuses["status_counts"] = dict(counts)
    statuses["completed"] = len(statuses["results"])
    STATUS_PATH.write_text(json.dumps(statuses, ensure_ascii=False, indent=2), encoding="utf-8")
    for row in rows:
        item = by_pmid[row["pmid"]]
        row["full_text_status"] = item["status"]
        row["full_text_path"] = item.get("path", "")
        row["full_text_text_path"] = item.get("text_path", "")
    (ROOT / "bibliography.json").write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
    with (ROOT / "bibliography.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"openaire_records_matched": len(records_by_pmid), "records_with_open_urls": len(tasks), "new_downloads": downloaded, "status_counts": dict(counts)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

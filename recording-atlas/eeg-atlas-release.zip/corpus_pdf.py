"""Resolve original article PDFs and render figure pages for Harness."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from functools import lru_cache
import unicodedata
import re
import shutil
import subprocess

ROOT=Path(__file__).parent/"Корпус PDF"
ORIGINALS=Path(__file__).parent/"Корпус оригиналы"
MAX_PDF=20*1024*1024
FIGURE=re.compile(r"(?im)^[ \t]*(?:figure|fig\.)[ \t]*s?\d+(?:[a-z])?[ \t]*(?:[.:|–—]|[ \t]{2,})")


def is_pdf(path):
    try:
        with path.open("rb") as source:
            return 0<path.stat().st_size<=MAX_PDF and b"%PDF-" in source.read(1024)
    except OSError:
        return False


def get_pdf(aid,meta):
    target=ROOT/(aid+".pdf")
    if is_pdf(target):
        return target
    pmc=str(meta.get("pmcid") or "")
    pmid=str(meta.get("pmid") or "")
    names=[aid,*[x for x in (pmc,pmid) if re.fullmatch(r"(?:PMC)?\d+",x)]]
    for folder in (ROOT,Path.home()/"Downloads",Path(__file__).parent/"literature_search_2026-11-16/full_text_alternatives"):
        for name in names:
            local=folder/(name+".pdf")
            if is_pdf(local):
                ROOT.mkdir(exist_ok=True)
                if local!=target:
                    shutil.copyfile(local,target)
                return target
    return None


def get_original(aid,meta):
    pdf=get_pdf(aid,meta)
    if pdf:
        return pdf
    for suffix in (".html",".xml"):
        path=ORIGINALS/(aid+suffix)
        if path.is_file() and path.stat().st_size:
            return path
    return None


def choose_originals(ids,registry,count):
    with ThreadPoolExecutor(max_workers=5) as pool:
        first=ids[:count]
        found=dict(zip(first,pool.map(lambda aid:get_original(aid,registry[aid]),first)))
        for start in range(count,len(ids),5):
            if sum(bool(path) for path in found.values())>=count:
                break
            group=ids[start:start+5]
            found.update(zip(group,pool.map(lambda aid:get_original(aid,registry[aid]),group)))
    ready=[aid for aid in ids if found.get(aid)][:count]
    selected=ready+[aid for aid in first if aid not in ready][:count-len(ready)]
    return selected,{aid:found[aid] for aid in ready}


def figure_pages(path,limit=4):
    text_tool=shutil.which("pdftotext")
    image_tool=shutil.which("pdftoppm")
    if not text_tool or not image_tool:
        return []
    flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
    try:
        text=subprocess.run([text_tool,"-layout","-enc","UTF-8",str(path),"-"],capture_output=True,
                            encoding="utf-8",errors="replace",timeout=30,check=True,creationflags=flags).stdout
        pages=[n for n,body in enumerate(text.split("\f"),1) if FIGURE.search(body)][:limit]
        result=[]
        for n in pages:
            prefix=path.with_name(f"{path.stem}-p{n}-{path.stat().st_mtime_ns}")
            image=prefix.with_suffix(".jpg")
            if not image.exists():
                subprocess.run([image_tool,"-f",str(n),"-l",str(n),"-singlefile","-scale-to","1700",
                                "-jpeg",str(path),str(prefix)],capture_output=True,check=True,timeout=30,
                               creationflags=flags)
            if image.exists():
                result.append((n,image))
        return result
    except (OSError,subprocess.SubprocessError):
        return []


def visual_files(path,limit=4):
    if path.suffix==".pdf":
        return [(f"страница PDF {number}",image) for number,image in figure_pages(path,limit)]
    folder=ORIGINALS/path.stem
    return [(file.name,file) for file in sorted(folder.glob("*"))
            if file.suffix.lower() in {".jpg",".jpeg",".png"} and file.stat().st_size<=4*1024*1024][:limit]


def normalize_pdf_text(value):
    value=unicodedata.normalize("NFKC",value).casefold().replace("­","")
    return "".join(re.findall(r"\w+",value)).replace("_","")


@lru_cache(maxsize=48)
def pdf_pages(path,stamp):
    tool=shutil.which("pdftotext")
    if not tool:
        return ()
    try:
        text=subprocess.run([tool,"-enc","UTF-8",str(path),"-"],capture_output=True,
                            encoding="utf-8",errors="replace",timeout=35,check=True,
                            creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)).stdout
    except (OSError,subprocess.SubprocessError):
        return ()
    return tuple(normalize_pdf_text(page) for page in text.split("\f"))


def quote_page(path,quote):
    if not path or path.suffix.casefold()!=".pdf":
        return None
    needle=normalize_pdf_text(quote)
    if len(needle)<24:
        return None
    pages=pdf_pages(path,path.stat().st_mtime_ns)
    for i,page in enumerate(pages):
        if needle in page:
            return i+1
        if i+1<len(pages) and needle in (page[-len(needle)+1:]+pages[i+1][:len(needle)-1]):
            return i+1
    return None

"""Local cache for completed, validated Harness stages."""
from contextlib import closing
from functools import lru_cache
import os
from pathlib import Path
import sqlite3
import tempfile


STAGE_CACHE=Path(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir())/"EEGAtlas"/"plan-stages.sqlite"


@lru_cache(maxsize=1)
def stage_cache():
    STAGE_CACHE.parent.mkdir(parents=True,exist_ok=True)
    with closing(sqlite3.connect(STAGE_CACHE)) as db, db:
        db.execute("CREATE TABLE IF NOT EXISTS results (key TEXT PRIMARY KEY, reply TEXT, updated INTEGER)")
        db.execute("CREATE TABLE IF NOT EXISTS conversations "
                   "(key TEXT PRIMARY KEY, workspace TEXT, session TEXT)")
        db.execute("CREATE TABLE IF NOT EXISTS pending "
                   "(key TEXT PRIMARY KEY, marker TEXT, started REAL)")
    return STAGE_CACHE


def get_stage(key):
    with closing(sqlite3.connect(stage_cache())) as db:
        row=db.execute("SELECT reply FROM results WHERE key=?",(key,)).fetchone()
    return row[0] if row else None


def save_stage(key,reply):
    with closing(sqlite3.connect(stage_cache())) as db, db:
        db.execute("INSERT OR REPLACE INTO results VALUES (?, ?, unixepoch())",(key,reply))
        db.execute("DELETE FROM results WHERE key IN "
                   "(SELECT key FROM results ORDER BY updated DESC, key LIMIT -1 OFFSET 300)")



def get_conversation(key,workspace):
    with closing(sqlite3.connect(stage_cache())) as db:
        row=db.execute("SELECT session FROM conversations WHERE key=? AND workspace=?",(key,workspace)).fetchone()
    return row[0] if row else None


def save_conversation(key,workspace,session):
    with closing(sqlite3.connect(stage_cache())) as db, db:
        db.execute("INSERT OR REPLACE INTO conversations VALUES (?, ?, ?)",(key,workspace,session))


def get_pending(key):
    with closing(sqlite3.connect(stage_cache())) as db:
        return db.execute("SELECT marker, started FROM pending WHERE key=?",(key,)).fetchone()


def save_pending(key,marker,started):
    with closing(sqlite3.connect(stage_cache())) as db, db:
        db.execute("INSERT OR REPLACE INTO pending VALUES (?, ?, ?)",(key,marker,started))


def clear_pending(key):
    with closing(sqlite3.connect(stage_cache())) as db, db:
        db.execute("DELETE FROM pending WHERE key=?",(key,))

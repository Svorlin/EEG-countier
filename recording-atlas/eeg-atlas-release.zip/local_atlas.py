"""Local EEG profiling with MNE-Python, SciPy, NumPy and PyPREP."""
from collections import Counter
from contextlib import closing
from functools import lru_cache
from html import escape
from importlib.metadata import version
from pathlib import Path, PureWindowsPath
import hashlib
import csv
import math
import json
import re
import secrets
import tempfile
import threading
import sys
import webbrowser

from flask import Flask, Response, abort, jsonify, request, send_file
import mne
import numpy as np
from scipy.signal import butter, find_peaks, sosfiltfilt, welch
from scipy.stats import median_abs_deviation, pearsonr
from pyprep import NoisyChannels
from werkzeug.serving import make_server
from corpus_pdf import get_pdf
from corpus_review import PROMPT, corpus, packet, recording_verdict, review, saved_texts
from corpus_search import index as corpus_index, rebuilt_matrix, rebuilt_matrix_path, run_search
from corpus_search_tool import open_passage, read_only
from subprocess import TimeoutExpired

ROOT = Path(__file__).resolve().parent
ATLAS = ROOT / "Атлас с анализом записи.html"
BANDS = {"delta": (.5, 4), "theta": (4, 8), "alpha": (8, 13), "beta": (13, 30), "gamma": (30, 45)}
ROLES = {"eog": "EOG", "ecg": "ECG", "emg": "EMG", "stim": "Метки"}
VOLTAGE_TYPES = {"eeg", "eog", "ecg", "emg"}
PROFILE_VERSIONS = {name: version(name) for name in ("mne", "scipy", "numpy", "pyprep")}
mne.set_log_level("WARNING")
TOKEN = secrets.token_urlsafe(32)
app = Flask(__name__)
app.config.update(MAX_CONTENT_LENGTH=1024**3, MAX_FORM_PARTS=8)


def number(value):
    return float(value) if np.isfinite(value) else None


def json_values(obj):
    if isinstance(obj, np.generic):
        return json_values(obj.item())
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {key: json_values(value) for key, value in obj.items()}
    if isinstance(obj, (tuple, list)):
        return [json_values(value) for value in obj]
    return obj


MONTAGE = mne.channels.make_standard_montage("colin27_1020")
MONTAGE_POSITIONS = {name.casefold(): xyz for name,xyz in MONTAGE.get_positions()["ch_pos"].items()}
MONTAGE_NAMES = MONTAGE_POSITIONS.keys()
MONTAGE_RADIUS = max(np.hypot(*xyz[:2]) for xyz in MONTAGE_POSITIONS.values())
REFERENCE_LABEL = re.compile(r"^(?:M[12]|A[12]|LE|RE|mastoid[ _-]?[LR])$", re.I)


def channel_metadata(label, unit, kind=None, positioned=False):
    name = re.sub(r"^EEG[ :_-]+", "", label, flags=re.I)
    electrode = re.sub(r"[-_ ](?:REF|LE|RE)$", "", name, flags=re.I)
    role, basis = "Не задан", "Нет однозначных сведений о подключении."
    if kind in ROLES:
        role, basis = ROLES[kind], "Тип канала прочитан MNE из разметки записи."
    elif re.fullmatch(r"(?:reference|ref)",name,re.I):
        role, basis = "Референс", "Явная служебная метка REF в заголовке."
    elif re.fullmatch(r"(?:gnd|ground)",name,re.I):
        role, basis = "Земля", "Явная служебная метка GND в заголовке."
    elif REFERENCE_LABEL.fullmatch(name):
        basis = "Метка уха или сосцевидного электрода. Его роль зависит от монтажа."
    else:
        named_roles = (
            (r"^(?:[hv]eog|eog|heogl|heogr|veogb)", "EOG"),
            (r"^(?:ecg|ekg)", "ECG"), (r"^emg", "EMG"),
            (r"^(?:accel|gyro|acc\b)", "Движение"),
            (r"^(?:annotations?|event|status|trigger|marker|stim)", "Метки")
        )
        role = next((role for pattern,role in named_roles if re.search(pattern,name,re.I)), None)
        if role:
            basis = "Явное обозначение типа в имени канала."
        elif positioned or electrode.casefold() in MONTAGE_NAMES or name != label:
            role = "ЭЭГ"
            basis = "Электрод совпадает со стандартным монтажом MNE." if electrode.casefold() in MONTAGE_NAMES else "Разметка ЭЭГ в источнике."
        else:
            role = "Не задан"
    meta = {"label":label, "role":role, "unit":unit, "roleBasis":basis, "roleNeedsReview":role=="Не задан"}
    if electrode.casefold() in MONTAGE_POSITIONS and role=="ЭЭГ":
        xy=MONTAGE_POSITIONS[electrode.casefold()][:2]/MONTAGE_RADIUS
        meta["sensorXY"]=[round(float(x),4) for x in xy]
    return meta


def spectral_share(freq, psd, low, high, upper=90):
    signal = psd[(freq>=1)&(freq<upper)].sum()
    return float(psd[(freq>=low)&(freq<high)].sum()/signal) if signal>0 else 0


def infer_unlabeled_roles(meta, blocks, fs):
    if fs < 20:
        return
    block = max(blocks, key=lambda values:values.shape[1])
    front = [i for i,c in enumerate(meta) if c["role"]=="ЭЭГ" and re.match(r"^(?:EEG[ :_-]+)?(?:Fp|AF)",c["label"],re.I)]
    eeg = [i for i,c in enumerate(meta) if c["role"]=="ЭЭГ" and np.isfinite(block[i]).all()]
    width = min(block.shape[1],round(fs*2))
    if width < 32:
        return
    def psd(values):
        return welch(values,fs=fs,nperseg=width,axis=-1)
    eeg_high = None
    if eeg and fs>=190:
        f, powers = psd(block[eeg])
        eeg_high = float(np.median([spectral_share(f,p,35,90) for p in powers]))
    for i,c in enumerate(meta):
        if not c["roleNeedsReview"] or REFERENCE_LABEL.fullmatch(c["label"]):
            continue
        x=block[i]
        if np.isfinite(x).all() and np.ptp(x)>0:
            levels = np.unique(x)
            if 2<=len(levels)<=16 and levels[0]==0 and levels[-1]<=65535 and np.all(levels==np.floor(levels)):
                changed=np.count_nonzero(np.diff(x))
                if changed<=len(x)*.05:
                    raw=mne.io.RawArray(x[None,:],mne.create_info(["STI"],fs,"stim"),verbose="ERROR")
                    events=mne.find_events(raw,stim_channel="STI",shortest_event=1,verbose="ERROR")
                    if len(events)>=3:
                        c.update(role="Метки",roleNeedsReview=False,
                                 roleBasis=f"MNE нашёл {len(events)} переходов по дискретным кодам на проверенном отрезке.")
                        continue
            suggestions=[]
            if fs>=100 and len(x)>=fs*6:
                y=sosfiltfilt(butter(3,[5,25],btype="bandpass",fs=fs,output="sos"),x)
                magnitude=np.abs(y)
                scale=median_abs_deviation(y,scale="normal")
                peaks,_=find_peaks(magnitude,distance=round(.33*fs),prominence=max(6*scale,.12*magnitude.max()))
                intervals=np.diff(peaks)/fs
                if len(intervals)>=5:
                    typical=float(np.median(intervals))
                    regular=float(median_abs_deviation(intervals)/typical)
                    if .42<=typical<=1.45 and regular<=.12:
                        suggestions.append(("ECG",f"SciPy нашёл {len(peaks)} выраженных регулярных пиков, медианный интервал {typical:.2f} с."))
            f,p=psd(x)
            if len(x)>=fs*4 and front and spectral_share(f,p,1,5)>.7:
                slow=butter(3,[.5,5],btype="bandpass",fs=fs,output="sos")
                sx=sosfiltfilt(slow,x)
                coefficients=[abs(float(pearsonr(sx,sosfiltfilt(slow,block[j])).statistic))
                              for j in front if np.isfinite(block[j]).all() and np.ptp(block[j])>0]
                if coefficients and max(coefficients)>.8:
                    suggestions.append(("EOG",f"Преобладает медленная активность, корреляция с фронтальным каналом до {max(coefficients):.2f}."))
            if eeg_high is not None and spectral_share(f,p,35,90)>max(.6,eeg_high*2.5):
                suggestions.append(("EMG","Доля мощности 35–90 Гц существенно выше, чем у известных ЭЭГ-каналов."))
            if suggestions:
                c["roleSuggestions"]=[{"role":role,"basis":basis} for role,basis in suggestions]

def spans(count, fs, channel_count):
    if not fs:
        return [(0, count)]
    cap = min(round(fs * 120), max(1, 4_000_000 // channel_count))
    if count <= cap:
        return [(0, count)]
    width = max(1, cap // 3)
    return [(start, start + width) for start in (0, (count - width) // 2, count - width)]


def spectrum(values, fs):
    if fs < 8:
        return None
    seg = min(len(values), round(2 * fs))
    if seg < 32 or seg / fs < .75:
        return None
    overlap = seg // 2
    windows = np.lib.stride_tricks.sliding_window_view(values, seg)[::seg-overlap]
    windows = windows[np.isfinite(windows).all(axis=1)]
    if not len(windows):
        return None
    f, psd = welch(windows, fs=fs, window="hann", nperseg=seg, noverlap=0, detrend="constant", axis=-1)
    psd = psd.mean(axis=0)
    delta = f[1] - f[0]

    def power(lo, hi):
        return float(psd[(f >= lo) & (f < hi)].sum() * delta)

    bands = {key: power(*band) if fs / 2 >= band[1] else None for key, band in BANDS.items()}
    broad = power(4, min(30, fs / 2))
    alpha_picks = (f >= 8) & (f < 13)
    lines = {}
    for frequency in (50, 60):
        if fs / 2 < frequency + 9 or delta > 1.5:
            continue
        line = power(frequency - 1.5, frequency + 1.5)
        neighbors = (power(frequency - 8, frequency - 5) + power(frequency + 5, frequency + 8)) / 2
        lines[frequency] = {"rms": math.sqrt(line), "ratio": line / neighbors if neighbors > 0 else None}
    trace=(f>=0)&(f<=90)
    return {
        "resolution": float(delta), "windows": len(windows), "bands": bands, "line": lines,
        "trace_db": [number(v) for v in np.where(psd[trace]>0,10*np.log10(np.maximum(psd[trace],np.finfo(float).tiny)),np.nan)],
        "alphaShare": bands["alpha"] / broad if bands["alpha"] is not None and broad else None,
        "alphaPeak": float(f[alpha_picks][psd[alpha_picks].argmax()]) if psd[alpha_picks].any() else None,
    }


def quality(blocks, starts, fs):
    values = np.concatenate(blocks)
    finite = values[np.isfinite(values)]
    total = len(finite)
    result = {"n": total, "missing": len(values) - total, "robust": None, "sections": [],
              "flat": False, "spikes": 0, "zeros": 0, "unstable": False, "saturation": None}
    if not total:
        return result
    low, q1, median, q3, high = np.quantile(finite, [.01, .25, .5, .75, .99])
    mad = median_abs_deviation(finite)
    threshold = 8 * 1.4826 * mad
    minimum, maximum = np.min(finite), np.max(finite)
    longest = 0
    for x, start in zip(blocks, starts):
        valid = np.isfinite(x)
        same = valid[1:] & valid[:-1] & (x[1:] == x[:-1])
        edges = np.r_[0, np.flatnonzero(~same) + 1, len(x)]
        lengths = np.diff(edges)
        longest = max(longest, int(lengths[valid[edges[:-1]]].max(initial=0)))
        sd = float(np.std(x[valid])) if valid.any() else None
        with np.errstate(invalid="ignore", over="ignore"):
            jumps = int(np.count_nonzero(np.isfinite(np.diff(x)) & (np.abs(np.diff(x)) > threshold))) if threshold else 0
        result["sections"].append({"start": start / fs if fs else 0, "n": int(valid.sum()), "length": len(x),
                                   "sd": sd, "jumps": jumps, "spectrum": spectrum(x, fs)})
    scales = [section["sd"] for section in result["sections"] if section["sd"]]
    result.update(
        robust={"median": float(median), "mad": float(mad), "p01": float(low), "p99": float(high), "iqr": float(q3-q1)},
        sd=float(np.std(finite)), rms=float(np.sqrt(np.mean(np.square(finite)))), mean=float(np.mean(finite)),
        min=float(minimum), max=float(maximum), range=float(maximum-minimum),
        zeros=int(np.count_nonzero(finite == 0)),
        spikes=int(np.count_nonzero(np.abs(finite-median) > threshold)) if threshold else 0,
        flat=bool(total > 1 and (minimum == maximum or (fs and longest/fs >= 1))),
        flatSeconds=longest/fs if fs else None,
        saturation=float(max(np.count_nonzero(finite == minimum), np.count_nonzero(finite == maximum))/total) if minimum != maximum else None,
        unstable=len(scales) > 1 and max(scales)/min(scales) >= 3,
    )
    return result


def references(meta, blocks, fs):
    if not fs:
        return []
    all_data = np.concatenate(blocks, axis=1)[:, ::max(1, round(fs / 128))]
    rows = []
    for i, chan in enumerate(meta):
        if chan["role"] not in ("EOG", "ECG", "EMG", "Движение", "Не задан"):
            continue
        for j, eeg in enumerate(meta):
            if eeg["role"] != "ЭЭГ":
                continue
            mask = np.isfinite(all_data[[i, j]]).all(axis=0)
            x, y = all_data[[j, i]][:, mask]
            if len(x) >= 32 and np.ptp(x) and np.ptp(y):
                rows.append({"signal": eeg["label"], "reference": chan["label"], "r": number(pearsonr(x, y).statistic)})
    return rows


def prep_flags(meta, blocks, fs):
    candidates = [i for i, c in enumerate(meta) if c["role"] == "ЭЭГ"]
    if len(candidates) < 5 or fs < 100:
        return {}, 0
    flags = {}
    checked = 0
    for block in blocks:
        if block.shape[1] < 5 * fs or not np.isfinite(block[candidates]).all() or np.count_nonzero(np.ptp(block[candidates], axis=1)) < 5:
            continue
        names = [meta[i]["label"] for i in candidates]
        if any(meta[i]["unit"] != "мкВ" for i in candidates):
            continue
        raw = mne.io.RawArray(block[candidates] * 1e-6, mne.create_info(names, fs, "eeg"), verbose="ERROR")
        nc = NoisyChannels(raw, do_detrend=True, random_state=0, ransac=False)
        nc.find_bad_by_deviation()
        nc.find_bad_by_correlation()
        nc.find_bad_by_hfnoise()
        checked += 1
        for tag, attr in (("разброс", "bad_by_deviation"), ("корреляция", "bad_by_correlation"),
                          ("ВЧ-шум", "bad_by_hf_noise"), ("плоский", "bad_by_flat"), ("NaN", "bad_by_nan")):
            for name in getattr(nc, attr, []):
                flags.setdefault(name, Counter())[tag] += 1
    return flags, checked


def waveform_preview(x, fs, start, diagnostic):
    if fs<=0 or len(x)<2:
        return None
    width=max(1,math.ceil(len(x)/2800))
    groups=math.ceil(len(x)/width)
    padded=np.full(groups*width,np.nan)
    padded[:len(x)]=x
    y=padded.reshape(groups,width)
    valid=np.isfinite(y)
    lows=np.where(valid,y,np.inf).min(axis=1)
    highs=np.where(valid,y,-np.inf).max(axis=1)
    peaks=[]
    stats=diagnostic.get("robust") or {}
    mad=stats.get("mad") or 0
    if mad>0 and np.isfinite(x).any():
        center=stats["median"]
        magnitude=np.where(np.isfinite(x),np.abs(x-center),0)
        idx,_=find_peaks(magnitude,height=8*1.4826*mad,distance=max(1,round(.04*fs)))
        highest=sorted(idx,key=lambda j:magnitude[j],reverse=True)[:10]
        peaks=[[round(start+j/fs,4),round(float(x[j]),4)] for j in sorted(highest)]
    return {"start":start,"end":start+(len(x)-1)/fs,"dt":width/fs,
            "lo":[round(float(v),4) if np.isfinite(v) else None for v in lows],
            "hi":[round(float(v),4) if np.isfinite(v) else None for v in highs],"peaks":peaks}


def temporal_quality(meta,blocks,fs,regular):
    indices=[i for i,ch in enumerate(meta) if ch["role"]=="ЭЭГ"]
    if not regular or not fs or not indices:
        return {}
    width=max(1,round(5*fs))
    windows=[]
    for block in blocks:
        for start in range(0,block.shape[1]-width+1,width):
            data=block[indices,start:start+width]
            valid=np.isfinite(data).all(axis=1)
            rms=np.full(len(indices),np.nan)
            rms[valid]=np.std(data[valid],axis=1)
            windows.append(rms)
    if not windows:
        return {}
    values=np.stack(windows)
    ratios=[]
    for column in values.T:
        finite=column[np.isfinite(column)]
        if finite.size>=4:
            low,high=np.percentile(finite,[10,90])
            if low>0:
                ratios.append(float(high/low))
    return {"rms_windows_5s":len(windows),"rms_comparable_channels":len(ratios),
            **({"rms_ratio_median":float(np.median(ratios)),
                "rms_ratio_p90":float(np.percentile(ratios,90))} if ratios else {})}


def profile(meta, blocks, picks, fs, count, recording_format, duration=None, regular=True):
    infer_unlabeled_roles(meta, blocks, fs)
    flags, prep_checked = prep_flags(meta, blocks, fs)
    for i, c in enumerate(meta):
        c.update(fs=fs, samples=count)
        if c["role"] == "Метки":
            c["quality"] = {"sections": [], "n": 0, "missing": 0}
            continue
        c["quality"] = quality([block[i] for block in blocks], [a for a, _ in picks], fs)
        if c["role"]=="ЭЭГ" and fs>0:
            c["waveform"]=[waveform_preview(block[i],fs,a/fs,c["quality"]) for block,(a,_) in zip(blocks,picks)]
        if c["label"] in flags:
            c["prep"] = flags[c["label"]]
    return {
        "engine": PROFILE_VERSIONS, "format": recording_format,
        "channels": meta, "duration": duration if duration is not None else count/fs if fs else None,
        "sampled": sum(b-a for a,b in picks) < count, "regular": regular,
        "windows": [{"start": a/fs, "end": b/fs} for a,b in picks] if fs else [],
        "prepChecked": prep_checked, "correlations": references(meta, blocks, fs),
        "temporalQuality":temporal_quality(meta,blocks,fs,regular),
    }


def read_record(entry):
    if entry.suffix.lower() == ".vhdr":
        raw = mne.io.read_raw_brainvision(entry, preload=False, verbose="ERROR")
        fmt = "BrainVision"
    elif entry.suffix.lower() == ".edf":
        raw = mne.io.read_raw_edf(entry, preload=False, infer_types=True, verbose="ERROR")
        fmt = "EDF"
    else:
        raw = mne.io.read_raw_bdf(entry, preload=False, infer_types=True, verbose="ERROR")
        fmt = "BDF"
    with raw:
        fs = float(raw.info["sfreq"])
        meta = [channel_metadata(label, "мкВ" if kind in VOLTAGE_TYPES else "", kind,
                                 kind=="eeg" and np.isfinite(ch["loc"][:3]).all() and bool(np.any(ch["loc"][:3])))
                for label,kind,ch in zip(raw.ch_names,raw.get_channel_types(),raw.info["chs"])]
        scale = np.array([1e6 if c["unit"] == "мкВ" else 1. for c in meta])[:, None]
        picks = spans(raw.n_times, fs, len(meta))
        blocks = [raw.get_data(start=a, stop=b) * scale for a,b in picks]
        result = profile(meta, blocks, picks, fs, raw.n_times, fmt)
        kinds, stimuli, stim_positions = Counter(), Counter(), []
        invalid = 0
        positions = raw.time_as_index(raw.annotations.onset - raw.first_time, use_rounding=True)
        for description, position in zip(raw.annotations.description, positions):
            if not 0 <= position < raw.n_times:
                invalid += 1
                continue
            kind, _, code = description.partition("/")
            kinds[kind] += 1
            if kind.casefold() == "stimulus":
                stimuli[code.strip()] += 1
                stim_positions.append(int(position))
        result.update(eventTypes=list(kinds.items()), stimulusCodes=list(stimuli.items()),
                      invalid=invalid, stimulusPositions=stim_positions, markerFs=fs)
        return result


def read_table(entry, hz, unit):
    with entry.open(encoding="utf-8-sig", newline="") as source:
        first = source.readline()
        delimiter = next((sep for sep in (";", "\t", ",") if sep in first), None)
        if delimiter is None:
            raise ValueError("CSV/TSV должен содержать несколько столбцов с заголовками.")
        source.seek(0)
        rows = csv.reader(source, delimiter=delimiter)
        names = [x.strip() for x in next(rows)]
        if any(not x for x in names) or len(set(names)) != len(names) or len(names)>256:
            raise ValueError("Имена столбцов должны быть непустыми и уникальными. Максимум 256 столбцов.")

        def value(x):
            try:
                return float(x if delimiter == "," else x.replace(",", "."))
            except ValueError:
                return np.nan

        data = []
        for row in rows:
            if len(row) != len(names):
                raise ValueError("В строках CSV различается число столбцов.")
            if len(data)*len(names) >= 4_000_000:
                raise ValueError("Больше 4 млн ячеек. Откройте более короткий фрагмент.")
            data.append([value(x) for x in row])
    if len(data) < 2:
        raise ValueError("Нужно минимум два отсчёта.")
    x = np.asarray(data, dtype=np.float64).T
    index = next((i for i,n in enumerate(names) if re.fullmatch(r"(?:time|timestamp)[ _]?\(?(?:ms|s)\)?", n, re.I)), None)
    fs = float(hz or 0)
    if fs and (not math.isfinite(fs) or not 1 <= fs <= 25000):
        raise ValueError("Частота CSV должна быть от 1 до 25000 Гц.")
    duration = (x.shape[1]-1)/fs if fs else None
    regular = True
    if index is not None:
        scale = .001 if "ms" in names[index].lower() else 1.
        delta = np.diff(x[index]) * scale
        if not np.isfinite(delta).all() or (delta <= 0).any():
            raise ValueError("Временная шкала должна строго возрастать.")
        duration = float(delta.sum())
        spacing = float(delta.mean())
        if fs and abs(fs*spacing-1)>.02:
            raise ValueError("Частота расходится с временной шкалой более чем на 2%.")
        fs = 1/spacing
        regular = bool(np.all(np.abs(delta/spacing-1)<=.02))
        x = np.delete(x, index, axis=0)
        names.pop(index)
    if not names:
        raise ValueError("После столбца времени нужен хотя бы один канал.")
    meta = [channel_metadata(n,unit) for n in names]
    return profile(meta, [x], [(0,x.shape[1])], fs if regular else 0, x.shape[1], "CSV/TSV", duration, regular)


def select_entry(directory, streams):
    names = [item.filename for item in streams]
    if any(not n or Path(n).name != n or PureWindowsPath(n).name != n or ":" in n for n in names):
        raise ValueError("Передайте файлы без путей.")
    if len({n.casefold() for n in names}) != len(names):
        raise ValueError("Имена файлов должны быть уникальными.")
    entries = [directory / n for n in names]
    header = next((p for p in entries if p.suffix.lower() == ".vhdr"), None)
    if header:
        if sorted(p.suffix.lower() for p in entries) != [".eeg", ".vhdr", ".vmrk"]:
            raise ValueError("Выберите комплект .vhdr, .eeg и .vmrk одной записи.")
        companions = {p.name for p in entries if p != header}
        for item, path in zip(streams, entries):
            if path.suffix.lower() in (".vhdr", ".vmrk"):
                start = item.stream.read(1_000_001)
                item.stream.seek(0)
                if len(start) > 1_000_000:
                    raise ValueError("Заголовок или файл маркеров больше 1 МБ.")
                links = re.findall(rb"^\s*(?:DataFile|MarkerFile)\s*=\s*([^\r\n]+)", start, re.M | re.I)
                refs = {v.strip().decode("utf-8", errors="replace") for v in links}
                try:
                    for v in links:
                        refs.add(v.strip().decode("cp1252"))
                except UnicodeDecodeError:
                    pass
                if not refs or any(ref not in companions for ref in refs if "\ufffd" not in ref):
                    # Non-ASCII filenames can use the header's codepage.
                    good = False
                    for encoding in ("utf-8-sig", "cp1252", "cp1251"):
                        try:
                            decoded = {v.strip().decode(encoding) for v in links}
                        except UnicodeDecodeError:
                            continue
                        good |= bool(decoded) and decoded <= companions
                    if not good:
                        raise ValueError("Ссылки BrainVision должны указывать на выбранные соседние файлы.")
        entry = header
    elif len(entries)==1 and entries[0].suffix.lower() in (".edf", ".bdf", ".csv", ".tsv"):
        entry = entries[0]
    else:
        raise ValueError("Поддерживаются BrainVision, EDF, BDF, CSV и TSV.")
    for path, item in zip(entries, streams):
        item.save(path)
    return entry


@app.before_request
def local_only():
    if request.host != app.config["ATLAS_HOST"]:
        abort(403)
    if request.method == "POST" and (
        request.headers.get("Origin") != "http://" + request.host
        or not secrets.compare_digest(request.headers.get("X-Atlas-Token", ""), TOKEN)
    ):
        abort(403)


@app.get("/")
def index():
    html = ATLAS.read_text(encoding="utf-8")
    reference=request.args.get("view")=="atlas" or "workspace" in request.args
    if not reference:
        head, _, body=html.partition("</head>")
        record_start=body.index('<dialog id="recordLab"')
        record_styles=body.rfind("<style>",0,record_start)
        html=(head+'</head><body><button id="recordOpen" type="button">Анализ записи ЭЭГ</button>'
              +body[record_styles:])
    html = html.replace(
        '<meta charset="utf-8">', '<meta charset="utf-8"><meta name="atlas-token" content="' + TOKEN + '">', 1
    ).replace("connect-src 'none'", "connect-src 'self'", 1)
    return Response(html, mimetype="text/html", headers={"Cache-Control": "no-store", "X-Frame-Options": "DENY",
                     "Referrer-Policy": "no-referrer"})


@app.get("/corpus/status")
def corpus_status():
    with closing(read_only(corpus_index())) as db:
        full_texts=db.execute("SELECT COUNT(DISTINCT id) FROM passages").fetchone()[0]
    matrix=rebuilt_matrix()
    pairs={pair for article in matrix["articles"].values() for a,b,_ in article["pairs"] for pair in ((a,b),)}
    return jsonify(full_texts=full_texts, terms=len(matrix["terms"]),
                   aliases=sum(len(term["aliases"]) for term in matrix["terms"]),
                   matrix_articles=len(matrix["articles"]), matrix_cells=len(pairs),
                   matrix_count=len(matrix["level_pairs"]))


@app.get("/corpus/matrix")
def corpus_matrix():
    raw=rebuilt_matrix_path().read_text(encoding="utf-8")
    return Response(raw.removeprefix("const WINDOW_MATRIX=").strip().removesuffix(";"),
                    mimetype="application/json",headers={"Cache-Control":"no-store"})


@lru_cache(maxsize=1)
def matrix_previews():
    matrix=rebuilt_matrix()
    terms=matrix["terms"]
    articles=matrix["articles"].values()
    support=Counter(term for article in articles for term in set(article["term_hits"]))
    pairs=Counter(tuple(sorted((a,b))) for article in articles for a,b in {(a,b) for a,b,_ in article["pairs"]})
    previews=[]
    for source,target in matrix["level_pairs"]:
        eligible=[(a,b,n) if terms[a]["level"]==source else (b,a,n)
                  for (a,b),n in pairs.items() if {terms[a]["level"],terms[b]["level"]}=={source,target}]
        def axis(ids):
            ordered=sorted(set(ids),key=lambda i:(-support[i],terms[i]["label"].casefold()))
            return ordered[:math.ceil(len(ordered)*.4)]
        rows=axis(a for a,_,_ in eligible)
        columns=axis(b for _,b,_ in eligible)
        previews.append(dict(source=source,target=target,rows=[terms[i]["label"] for i in rows],
                             columns=[terms[i]["label"] for i in columns],
                             values=[[pairs[tuple(sorted((a,b)))] for b in columns] for a in rows],
                             maximum=max((n for _,_,n in eligible),default=1)))
    return previews


@app.get("/corpus/previews")
def corpus_previews():
    with closing(read_only(corpus_index())) as db:
        count=db.execute("SELECT COUNT(DISTINCT id) FROM passages").fetchone()[0]
    return jsonify(full_texts=count,matrices=matrix_previews())


@app.get("/corpus/pdf/<aid>")
def corpus_pdf(aid):
    meta=corpus()[1].get(aid)
    path=get_pdf(aid,meta) if meta else None
    if not path:
        abort(404)
    return send_file(path,mimetype="application/pdf",conditional=True)


@app.get("/corpus/article/<aid>/<int:section>")
def corpus_article(aid,section):
    quote=request.args.get("quote","")
    meta=corpus()[1].get(aid)
    if not meta or not quote or len(quote)>2000:
        abort(404)
    with closing(read_only(corpus_index())) as db:
        passage=open_passage(db,aid,section)
    if not passage or quote not in passage["text"]:
        abort(404)
    body=passage["text"]
    label="Фрагмент из локального индекса"
    path=saved_texts().get(aid) or saved_texts().get(meta.get("pmcid"))
    if path:
        try:
            full=path.read_text(encoding="utf-8-sig")
        except (OSError,UnicodeError):
            full=""
        if quote in full:
            body,label=full,"Локальный полный текст"
    before,_,after=body.partition(quote)
    title=escape(meta["title"])
    page=(f'<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
          f'<title>{title}</title><style>body{{max-width:78ch;margin:24px auto;padding:0 16px;font:16px/1.6 system-ui}}'
          'article{white-space:pre-wrap;overflow-wrap:anywhere}mark{background:#ffe68b;color:#172337;scroll-margin-top:24px}</style>'
          f'<main><h1>{title}</h1><p>{label} · {escape(aid)}</p><article>{escape(before)}'
          f'<mark id="quote">{escape(quote)}</mark>{escape(after)}</article></main></html>')
    return Response(page,mimetype="text/html",headers={"Cache-Control":"no-store",
                    "Content-Security-Policy":"default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'"})


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="Запись превышает локальный предел 1 ГБ."), 413


def recording_key(files):
    digest=hashlib.sha256()
    for item in sorted(files,key=lambda path:path.suffix.casefold()):
        digest.update(item.suffix.casefold().encode("utf-8")+b"\0")
        with item.open("rb") as source:
            digest.update(hashlib.file_digest(source,"sha256").digest())
    return digest.hexdigest()


@app.post("/profile")
def record_profile():
    files = request.files.getlist("files")
    try:
        with tempfile.TemporaryDirectory(prefix="eeg-atlas-") as folder:
            entry = select_entry(Path(folder), files)
            result = (read_table(entry, request.form.get("fs"), request.form.get("unit", "")[:16])
                      if entry.suffix.lower() in (".csv", ".tsv") else read_record(entry))
            result["recording_key"]=recording_key(path for path in Path(folder).iterdir() if path.is_file())
        return jsonify(json_values(result))
    except (ValueError, OSError, RuntimeError, UnicodeError) as error:
        return jsonify(error=str(error)), 422


@app.post("/profile/examples")
def example_profiles():
    directory=Path.home()/"Downloads/Telegram Desktop"
    result=[]
    for suffix, study in (("ZG","rest"),("OG","rest"),("ANT","ant")):
        name=f"Turnikov_{suffix}"
        files=[directory/(name+ext) for ext in (".vhdr",".eeg",".vmrk")]
        entry={"name":files[0].name,"study":study}
        try:
            if not all(path.is_file() for path in files):
                raise FileNotFoundError("Комплект BrainVision отсутствует в папке Загрузки → Telegram Desktop.")
            entry["record"]=read_record(files[0])
            entry["record"]["recording_key"]=recording_key(files)
        except (ValueError,OSError,RuntimeError,UnicodeError) as error:
            entry["error"]=str(error)
        result.append(entry)
    return jsonify(json_values(result))


@app.post("/review-packet")
def export_review_packet():
    if request.content_length is None or request.content_length>150000:
        return jsonify(error="Слишком большой пакет сверки."), 413
    try:
        return jsonify(instructions=PROMPT.strip(), **packet(request.get_json(silent=True)))
    except ValueError as exc:
        return jsonify(error=str(exc)), 422


SEARCH_PROGRESS_DIR = tempfile.TemporaryDirectory(prefix="atlas-progress-")


def progress_file(job):
    if not re.fullmatch(r"[0-9a-f]{32}",job or ""):
        abort(400)
    return Path(SEARCH_PROGRESS_DIR.name)/(job+".json")


@app.get("/search-corpus/progress/<job>")
def search_progress(job):
    if not secrets.compare_digest(request.headers.get("X-Atlas-Token",""),TOKEN):
        abort(403)
    path=progress_file(job)
    try:
        state=json.loads(path.read_text(encoding="utf8"))
    except (OSError,ValueError):
        state={"stage":"Подготовка индекса и срезов матриц","activity":[],"calls":0,"completed":0}
    return jsonify(state),200,{"Cache-Control":"no-store"}


@app.post("/search-corpus")
def search_for_record():
    if request.content_length is None or request.content_length>150000:
        return jsonify(error="Слишком большой запрос к корпусу."), 413
    job=request.headers.get("X-Atlas-Progress")
    progress=progress_file(job) if job else None
    try:
        return jsonify(run_search(request.get_json(silent=True),progress))
    except ValueError as exc:
        return jsonify(error=str(exc)), 422
    except TimeoutExpired:
        return jsonify(error="Harness не завершил поиск за отведённое время."), 504
    except (OSError, RuntimeError) as exc:
        return jsonify(error=str(exc)), 502
    finally:
        if progress:
            for path in (progress,progress.with_suffix(".tmp")):
                try:
                    path.unlink(missing_ok=True)
                except OSError:
                    pass


@app.post("/recording-verdict")
def verdict_for_record():
    if request.content_length is None or request.content_length>12000:
        return jsonify(error="Профиль записи слишком велик."),413
    try:
        return jsonify(recording_verdict(request.get_json(silent=True)))
    except ValueError as exc:
        return jsonify(error=str(exc)),422
    except TimeoutExpired:
        return jsonify(error="Harness не завершил оценку за отведённое время."),504
    except (OSError,RuntimeError) as exc:
        return jsonify(error=str(exc)),502


@app.post("/review")
def review_profile():
    if request.content_length is None or request.content_length>150000:
        return jsonify(error="Слишком большой пакет сверки."), 413
    try:
        return jsonify(review(request.get_json(silent=True)))
    except ValueError as exc:
        return jsonify(error=str(exc)), 422
    except TimeoutExpired:
        return jsonify(error="DeepSeek не ответил за отведённое время."), 504
    except (OSError, RuntimeError) as exc:
        return jsonify(error=str(exc)), 502


def main():
    server = make_server("127.0.0.1", 0, app, threaded=True)
    app.config["ATLAS_HOST"] = f"127.0.0.1:{server.server_port}"
    url = "http://" + app.config["ATLAS_HOST"] + "/" + ("?examples=1" if "--examples" in sys.argv else "")
    print(f"Локальный атлас: {url}", flush=True)
    threading.Timer(.3, webbrowser.open, args=(url,)).start()
    server.serve_forever()


if __name__ == "__main__":
    main()


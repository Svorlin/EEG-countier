"""Submit one task to the existing signed-in local Harness Web session."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import time
from http.cookiejar import CookieJar
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import HTTPCookieProcessor, ProxyHandler, Request, build_opener
from uuid import uuid4

from harness_cache import clear_pending, get_conversation, get_pending, save_conversation, save_pending
import zstandard

HOME = Path(os.environ.get("DSH_HOME", Path.home()/".dsh"))
MARKER = "Проверочный ID запуска: "


def session_events(path):
    try:
        with path.open("rb") as f, zstandard.ZstdDecompressor().stream_reader(f,read_across_frames=True) as reader:
            text=io.TextIOWrapper(reader,encoding="utf8")
            events=[]
            for line in text:
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    break
            return events
    except (OSError,zstandard.ZstdError,UnicodeError):
        return []


def message_text(event):
    data=event.get("data",{})
    message=data.get("message",data)
    content=message.get("content",[]) if isinstance(message,dict) else []
    if isinstance(content,str):
        return content
    return "\n".join(item.get("text","") for item in content if isinstance(item,dict) and item.get("type")=="text")


def token_usage(events):
    usage=[event["data"]["usage"] for event in events if event.get("type")=="assistant/message"
           and isinstance(event.get("data",{}).get("usage"),dict)]
    if not usage:
        return None
    totals={key:sum(item.get(key) or 0 for item in usage)
            for key in ("inputTokens","outputTokens","cacheReadTokens","cacheWriteTokens")}
    totals["firstCacheReadTokens"]=usage[0].get("cacheReadTokens") or 0
    return totals


def update_progress(path,stage,events=()):
    if not path:
        return
    calls=[]
    for event in events:
        if event.get("type")!="tool/call":
            continue
        data=event.get("data",{})
        args=data.get("arguments",{})
        if isinstance(args,str):
            try:
                args=json.loads(args)
            except json.JSONDecodeError:
                args={}
        command=args.get("command","") if isinstance(args,dict) else ""
        query=re.search(r'corpus_search_tool\.py\s+search\s+["\x27]([^"\x27\r\n]{1,160})["\x27]',command)
        article=re.search(r'corpus_search_tool\.py\s+open\s+(CORPUS_\d+)\s+(\d+)',command)
        within=re.search(r'--id\s+(CORPUS_\d+)',command)
        if query:
            label=("Поиск внутри "+within[1]+": " if within else "Поиск по текстам: ")+query[1]
        elif article:
            label=f"Чтение {article[1]}, фрагмент {article[2]}"
        else:
            label="Выполнение инструментального шага Harness"
        calls.append(label)
    completed=sum(x.get("type")=="tool/result" for x in events)
    payload={"stage":stage,"calls":len(calls),"completed":completed,"activity":calls[-5:],
             "usage":token_usage(events)}
    target=Path(path)
    tmp=target.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False),encoding="utf8")
    try:
        tmp.replace(target)
    except PermissionError:
        pass


def own_result(marker, started, progress=None, scan=None, session=None):
    root=HOME/"sessions"
    paths=[]
    scan={} if scan is None else scan
    for folder in root.iterdir() if root.is_dir() else ():
        for path in folder.glob((session or "*")+"/session.v4.jsonl.zstd"):
            try:
                stamp=path.stat()
            except OSError:
                continue
            signature=(stamp.st_mtime_ns,stamp.st_size)
            if stamp.st_mtime>=started-1 and scan.get(path)!=signature:
                paths.append((path,signature))
    for path,signature in sorted(paths,key=lambda item:item[1],reverse=True):
        events=session_events(path)
        start=next((i for i,event in enumerate(events)
                    if event.get("type")=="user/message" and marker in message_text(event)),None)
        if start is None:
            scan[path]=signature
            continue
        own=events[start:]
        end=next((i for i,event in enumerate(own) if event.get("type")=="turn/end"),None)
        if end is None:
            update_progress(progress,"Поиск и чтение фрагментов" if any(e.get("type")=="tool/call" for e in own) else "Harness читает профиль и матрицу",own)
            return None
        own=own[:end+1]
        update_progress(progress,"Проверка итоговых цитат",own)
        messages=[event for event in own if event.get("type")=="assistant/message" and message_text(event).strip()]
        reason=own[-1].get("data",{}).get("reason",{}).get("kind")
        if not messages or reason!="completed":
            raise RuntimeError("Веб-профиль Harness завершил задачу без ответа.")
        return {"text":message_text(messages[-1]).strip(),"session":path.parent.name,
                "tool_calls":sum(event.get("type")=="tool/call" for event in own),"usage":token_usage(own)}


class HarnessWeb:
    base="http://127.0.0.1:3080"

    def __init__(self):
        state=Path(os.environ["LOCALAPPDATA"])/"DeepSeekHarnessLauncher/state.json"
        token=json.loads(state.read_text(encoding="utf8")).get("token")
        if not token:
            raise RuntimeError("Нет локального сеанса веб-профиля Harness.")
        self.http=build_opener(ProxyHandler({}),HTTPCookieProcessor(CookieJar()))
        try:
            with self.http.open(self.base+"/?"+urlencode({"token":token}),timeout=25):
                pass
        except (URLError,OSError) as exc:
            raise RuntimeError("Локальный веб-профиль Harness недоступен.") from exc

    def call(self,method,args,timeout=40):
        payload={"type":"client-request","rpcId":uuid4().hex,"method":method,"payload":{"args":args}}
        request=Request(self.base+"/api/"+method,json.dumps(payload,ensure_ascii=False).encode("utf-8"),
                        {"Content-Type":"application/json"})
        try:
            with self.http.open(request,timeout=timeout) as reply:
                result=json.load(reply)["result"]
        except (URLError,OSError,ValueError,KeyError) as exc:
            raise RuntimeError(f"Harness не ответил на операцию {method}.") from exc
        if not result.get("ok"):
            code=result.get("error",{}).get("code","ошибка Harness")
            raise RuntimeError(f"Harness отклонил операцию {method}: {code}.")
        return result.get("value")

    def conversation(self,workspace,key):
        path=str(Path(workspace).resolve(strict=True))
        workspace_data=self.call("workspace/create",{"request":{"path":path}})
        wid=workspace_data["workspace"]["workspaceId"]
        if workspace_data.get("created"):
            self.call("workspace/rename",{"request":{"workspaceId":wid,"title":"ЭЭГ Атлас"}})
        session=get_conversation(key,wid) if key else None
        if session and session not in workspace_data["workspace"]["sessionIds"]:
            raise RuntimeError("Чат этой записи отсутствует в рабочей области ЭЭГ Атлас.")
        if session is None:
            value=self.call("session/create",{"request":{"workspaceId":wid}})
            session=value["sessionId"]
            if key:
                save_conversation(key,wid,session)
        return session


def run(prompt,timeout=170,progress=None,workspace=None,conversation=None,attachments=()):
    update_progress(progress,"Подключение к веб-профилю Harness")
    client=HarnessWeb()
    session=client.conversation(workspace or Path(__file__).parent,conversation)
    fingerprint=[(kind,name,path,Path(path).stat().st_mtime_ns) for kind,name,path in attachments]
    key=hashlib.sha256((session+"\n"+prompt+repr(fingerprint)).encode()).hexdigest()
    pending=get_pending(key)
    if pending:
        marker,started=pending
    else:
        client.call("session/selectModel",{"request":{"sessionId":session,"provider":"deepseek-account",
                    "model":"deepseek-flash","reasoningEffort":"max"}})
        marker=MARKER+uuid4().hex
        message=prompt+"\n\n"+marker+" (служебный, не включай в ответ)."
        content=[{"type":"text","text":message}]
        for kind,name,path in attachments:
            encoded=base64.b64encode(Path(path).read_bytes()).decode("ascii")
            if kind in {"pdf","file"}:
                uploaded=client.call("fileUploads/upload",{"agentId":session,
                    "request":{"name":name,"data":encoded}},timeout=90)
                content.append({"type":"file","receiptId":uploaded["receiptId"]})
            else:
                media="image/png" if Path(path).suffix.lower()==".png" else "image/jpeg"
                content.extend([{"type":"text","text":name},
                                {"type":"image","mediaType":media,"data":encoded,"name":name}])
        started=time.time()
        client.call("session/prompt",{"request":{"sessionId":session,"requestId":uuid4().hex,"mode":"queue",
                    "content":content,"clientTimeZone":"Europe/Moscow"}},timeout=90)
        save_pending(key,marker,started)
    deadline=time.monotonic()+timeout
    scan={}
    while time.monotonic()<deadline:
        try:
            result=own_result(marker,started,progress,scan,session)
        except RuntimeError:
            clear_pending(key)
            raise
        if result:
            clear_pending(key)
            return result
        time.sleep(0.8)
    raise RuntimeError("Веб-профиль Harness не вернул итог за отведённое время.")


if __name__=="__main__":
    try:
        raw=sys.stdin.read()
        payload=json.loads(raw) if len(sys.argv)>5 and sys.argv[5]=="attachments" else {"prompt":raw}
        print(json.dumps(run(payload["prompt"],int(sys.argv[1]) if len(sys.argv)>1 else 170,
                             sys.argv[2] if len(sys.argv)>2 else None,sys.argv[3] if len(sys.argv)>3 else None,
                             sys.argv[4] if len(sys.argv)>4 else None,payload.get("attachments",())),
                         ensure_ascii=False))
    except Exception as exc:
        # Keep authentication and transport details out of the response.
        print(json.dumps({"error":str(exc) if type(exc) is RuntimeError else
                          "Не удалось завершить задачу через веб-профиль Harness."},ensure_ascii=False))
        sys.exit(1)
